package network;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;

public class Protocol {

   final static public int TYPE_UNDEFINED = -1;
   final static public int TYPE_EXIT = 0;
   final static public int TYPE_LOGIN_REQ = 1;
   final static public int TYPE_LOGIN_RES = 2;
   final static public int TYPE_CREATE_REQ = 3;
   final static public int TYPE_CREATE_RES = 4;
   final static public int TYPE_READ_REQ = 5;
   final static public int TYPE_READ_RES = 6;
   final static public int TYPE_UPDATE_REQ = 7;
   final static public int TYPE_UPDATE_RES = 8;
   final static public int TYPE_DELETE_REQ = 9;
   final static public int TYPE_DELETE_RES = 10;
   final static public int TYPE_CHECK_REQ = 11;
   final static public int TYPE_CHECK_RES = 12;
   final static public int TYPE_LOGOUT_REQ = 13;
   final static public int TYPE_LOGOUT_RES = 14;

   // 로그인 요청에 대한 코드
   final static public int LOGIN_REQ_REQ = 0;

   // 로그인 응답에 대한 코드
   final static public int LOGIN_RES_FAIL = 0;
   final static public int LOGIN_RES_SUCCESS = 1;
   final static public int LOGIN_RES_NO_ID = 2;
   final static public int LOGIN_RES_NO_PASSWD = 3;

   // 등록요청에 대한 코드
   final static public int CREATE_REQ_USER = 0;
   final static public int CREATE_REQ_REVIEW = 1;
   final static public int CREATE_REQ_THUMBS = 2;

   // 등록 응답에 대한 코드
   final static public int CREATE_RES_FAIL = 0;
   final static public int CREATE_RES_SUCCESS = 1;

   // 조회 요청에 대한 코드
   final static public int READ_REQ_USER = 0;
   final static public int READ_REQ_FESTIVAL = 1;
   final static public int READ_REQ_REVIEW = 2;
   final static public int READ_REQ_FESTIVAL_PERIOD = 3;
   final static public int READ_REQ_RESULTFESTIVAL = 4;
   final static public int READ_REQ_TAG = 5;
   final static public int READ_REQ_STATISTIC_RANK_STAR = 6;
   final static public int READ_REQ_STATISTIC_PREFER_MBTI = 7;
   final static public int READ_REQ_FESTIVAL_BY_THUMBS = 8;
   
   // 조회 응답에 대한 코드
   final static public int READ_RES_FAIL = 0;
   final static public int READ_RES_USER = 1;
   final static public int READ_RES_FESTIVAL = 2;
   final static public int READ_RES_FESTIVAL_PERIOD = 3;
   final static public int READ_RES_REVIEW = 4;
   final static public int READ_RES_RESULTFESTIVAL = 5;
   final static public int READ_RES_TAG = 6;
   final static public int READ_RES_STATISTIC_RANK_STAR = 7;
   final static public int READ_RES_STATISTIC_PREFER_MBTI = 8;
   final static public int READ_RES_FESTIVAL_BY_THUMBS = 9;

   // 수정 요청에 대한 코드
   final static public int UPDATE_REQ_USER = 0;
   final static public int UPDATE_REQ_USERCOUNT = 1;
   final static public int UPDATE_REQ_REVIEW = 2;
   final static public int UPDATE_REQ_MBTI = 3;

   // 수정 응답에 대한 코드
   final static public int UPDATE_RES_FAIL = 0;
   final static public int UPDATE_RES_SUCCESS = 1;

   // 삭제 요청에 대한 코드
   final static public int DELETE_REQ_USER = 0;
   final static public int DELETE_REQ_REVIEW = 1;
   final static public int DELETE_REQ_THUMBS = 2;

   // 삭제 응답에 대한 코드
   final static public int DELETE_RES_FAIL = 0;
   final static public int DELETE_RES_SUCCESS = 1;

   // 체크(확인) 요청에 대한 코드
   final static public int CHECK_REQ_ID = 0;
   final static public int CHECK_REQ_LOGIN_ID = 1;
   final static public int CHECK_REQ_LOGIN_PASSWD = 2;
   final static public int CHECK_REQ_THUMBS = 3;
   final static public int CHECK_REQ_ISTHUMBS = 4;

   // 체크(확인) 응답에 대한 코드
   final static public int CHECK_RES_FAIL = 0;
   final static public int CHECK_RES_SUCCESS = 1;
   
   // 로그아웃 요청에 대한 코드
   final static public int LOGOUT_REQ_REQ = 0;
   
   // 로그아웃 응답에 대한 코드
   final static public int LOGOUT_RES_FAIL = 0;
   final static public int LOGOUT_RES_SUCCESS = 1;

   // 길이
   public static final int LEN_TYPE = 1;
   public static final int LEN_CODE = 1;
   public static final int LEN_BODYLENGTH = 4;
   public static final int LEN_HEADER = 6;

   // Protocol 멤버 변수
   private byte type;
   private byte code;
   private int bodyLength;
   private byte[] body;

   // 생성자
   public Protocol() {
      this(TYPE_UNDEFINED, 0);
   }

   public Protocol(int type) {
      this(type, 0);
   }

   public Protocol(int type, int code) {
      setType(type);
      setCode(code);
      setBodyLength(0);
   }

   public byte getType() {
      return type;
   }

   public void setType(int type) {
      this.type = (byte) type;
   }

   public byte getCode() {
      return code;

   }

   public void setCode(int code) {
      this.code = (byte) code;
   }

   public int getBodyLength() {
      return bodyLength;
   }

   // Body Length는 직접 설정할 수 없음
   private void setBodyLength(int bodyLength) {
      this.bodyLength = bodyLength;
   }

   public Object getBody() {
      return deserialize(body);
   }

   public void setBody(Object body) {
      byte[] serializedObject = serialize(body);
      this.body = serializedObject;
      setBodyLength(serializedObject.length);
   }

   // 현재 header와 body로 패킷을 생성하여 리턴
   public byte[] getPacket() {
      byte[] packet = new byte[LEN_HEADER + getBodyLength()];
      packet[0] = getType();
      packet[LEN_TYPE] = getCode();
      System.arraycopy(intToByte(getBodyLength()), 0, packet, LEN_TYPE + LEN_CODE, LEN_BODYLENGTH);
      if (getBodyLength() > 0) {
         System.arraycopy(body, 0, packet, LEN_HEADER, getBodyLength());
      }
      return packet;
   }

   // 매개 변수 packet을 통해 header만 생성
   public void setPacketHeader(byte[] packet) {
      byte[] data;

      setType(packet[0]);
      setCode(packet[LEN_TYPE]);

      data = new byte[LEN_BODYLENGTH];
      System.arraycopy(packet, LEN_TYPE + LEN_CODE, data, 0, LEN_BODYLENGTH);
      setBodyLength(byteToInt(data));
   }

   // 매개 변수 packet을 통해 body를 생성
   public void setPacketBody(byte[] packet) {
      byte[] data;

      if (getBodyLength() > 0) {
         data = new byte[getBodyLength()];
         System.arraycopy(packet, 0, data, 0, getBodyLength());
         setBody(deserialize(data));
      }
   }

   // 직렬화
   private byte[] serialize(Object b) {
      try {
         ByteArrayOutputStream baos = new ByteArrayOutputStream();
         ObjectOutputStream oos = new ObjectOutputStream(baos);
         oos.writeObject(b);
         return baos.toByteArray();
      } catch (Exception e) {
         e.printStackTrace();
         return null;
      }
   }

   // 역직렬화
   private Object deserialize(byte[] b) {
      try {
         ByteArrayInputStream bais = new ByteArrayInputStream(b);
         ObjectInputStream ois = new ObjectInputStream(bais);
         Object ob = ois.readObject();
         return ob;
      } catch (Exception e) {
         e.printStackTrace();
         return null;
      }
   }

   private byte[] intToByte(int i) {
      return ByteBuffer.allocate(Integer.SIZE / 8).putInt(i).array();
   }

   private int byteToInt(byte[] b) {
      return ByteBuffer.wrap(b).getInt();
   }
}