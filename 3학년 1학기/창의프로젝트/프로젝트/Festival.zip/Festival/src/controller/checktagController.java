package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import DTO.Festival;
import DTO.Tag;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import network.Network;

public class checktagController implements Initializable{

    @FXML
    private AnchorPane check;
    
	@FXML
	private CheckBox[][] checkBox;

    @FXML
    private AnchorPane ap;
    
	String[] selecttag;
	int tagRow;
	int tagCol;
	int checkBoxsize;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		selecttag = new String[30];
	}

	@FXML
	public void register(MouseEvent event) throws Exception {
		int count = 0;
		for (int i = 0; i < tagRow; i++) {
			for (int j = 0; j < tagCol; j++) {
				if(i*4+j == checkBoxsize) {
					break;
				}
				if (checkBox[i][j].isSelected()) {
					selecttag[count++] = checkBox[i][j].getText();
				}
			}
		}
		if(count == 0) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("선택이 되지 않았습니다.");
			alert.setContentText("선택 해주세요~");

			alert.showAndWait();
		}
		else {		
			
			Tag [] arr = new Tag[count+1];
			arr[0] = new Tag(MainController.getPerson().getMbti());
			
			for(int i= 1; i<count+1; i++) {
				arr[i] = new Tag(selecttag[i-1]);
			}
			
			Stage s = (Stage) check.getScene().getWindow();
			s.close();

			FXMLLoader next = new FXMLLoader(getClass().getResource("/application/test_result.fxml"));

			Parent root = next.load();
			Stage stage = new Stage();
			stage.setScene(new Scene(root));
			stage.show();
			
			resultController pop = next.getController();
			pop.initData(arr);
		} 
	}

	public void setting(Tag[] t) {
		checkBoxsize = t.length;
		int count = 0; 
		tagRow = checkBoxsize/4 + 1;
		if(t.length<5) {
			tagCol = checkBoxsize;
		}
		else {
			tagCol = 4;
		}
		checkBox = new CheckBox[tagRow][tagCol]; 
		for (int i = 0; i < tagRow; i++) {
			for (int j = 0; j < tagCol; j++, count++) {
				if(count == checkBoxsize) {
					break;
				}
				checkBox[i][j] = new CheckBox(t[count].getName());
				ap.getChildren().add(checkBox[i][j]);
				checkBox[i][j].setLayoutX(14 + (100 * j)); //좌석별 x좌표
				checkBox[i][j].setLayoutY(14 + (25 * i)); //좌석별 y좌표
			}
		}
	}
}
