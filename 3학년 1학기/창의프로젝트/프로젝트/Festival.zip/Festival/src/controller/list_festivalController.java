package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import DTO.Festival;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import network.Network;

public class list_festivalController implements Initializable {

	@FXML
	private ComboBox<String> address1;

	@FXML
	private ListView<String> list;
	
	ObservableList<Festival> festival_list = FXCollections.observableArrayList();
	
	public void handlefindController(MouseEvent event) throws Exception{
		try {
			if(address1.getSelectionModel().isEmpty()) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("경고창");
				alert.setHeaderText("지역을 선택하지 않았습니다.");
				alert.setContentText("지역을 선택해주세요!");

				alert.showAndWait();
			}
			else {
				festival_list.clear();
				String s = address1.getSelectionModel().getSelectedItem().toString();

				Festival f = new Festival();
				f.setFestival_local_area(s);
				ArrayList<Festival> l = Network.read_Req_Festival(f);
				ObservableList<String> festival_list2 = FXCollections.observableArrayList();
				festival_list.addAll(l);
				for(int i =0; i<l.size(); i++) {
					festival_list2.add(l.get(i).getFestival_name());
				}
				list.setItems(festival_list2);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void choose(MouseEvent event) throws Exception{
		int index = list.getSelectionModel().getSelectedIndex();
		
		Festival f = new Festival();
		f= festival_list.get(index);
		FXMLLoader next = new FXMLLoader(getClass().getResource("/application/festival_info.fxml"));

		Parent root = next.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();

		fesitval_infoController pop = next.getController();
		pop.initData(f);
	}
	
	public void  initialize(URL location, ResourceBundle resources) {
		ObservableList<String> data = FXCollections.observableArrayList();
		data.addAll("강원도","경기도","경상남도", "경상북도","광주광역시","대구광역시","대전광역시","부산광역시","서울특별시","울산광역시","인천광역시","전라남도","전라북도","제주도","충청남도","충청북도");
		address1.setItems(data);
	}
}
