package controller;

import java.util.ArrayList;

import DTO.Festival;
import DTO.Tag;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import network.Network;
import network.Protocol;

public class resultController{

	@FXML
	private AnchorPane test;

	@FXML
	private Label name;

	@FXML
	private Label mbti;

	@FXML
	private ListView<String> list;

	@FXML
	private Label percent;

	ObservableList<Festival> festival_list = FXCollections.observableArrayList();

	@FXML
	public void closed(MouseEvent event) {
		Stage s = (Stage) test.getScene().getWindow();
		s.close();
	}

	@FXML
	public void choose(MouseEvent event) throws Exception{
		int index = list.getSelectionModel().getSelectedIndex();
		
		Festival f = new Festival();
		f= festival_list.get(index);
		FXMLLoader next = new FXMLLoader(getClass().getResource("/application/festival_info.fxml"));

		Parent root = next.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();

		fesitval_infoController pop = next.getController();
		pop.initData(f);
	}

	public void initData(Tag [] t) throws Exception {
		System.out.print(MainController.getPerson().getMbti());
		int mbtiresult = Network.update_Req_Mbti(MainController.getPerson().getMbti());
		if(mbtiresult == Protocol.UPDATE_RES_SUCCESS) {
			int result = Network.update_Req_UserCount(MainController.getPerson());
			if(result == Protocol.UPDATE_RES_SUCCESS) {
				double percentresult = Network.read_Req_Statistic_Prefer_Mbti(MainController.getPerson().getMbti());
				
				name.setText(MainController.getPerson().getName());
				mbti.setText(MainController.getPerson().getMbti());
				percent.setText(String.valueOf(percentresult));
				ArrayList<Festival> l = Network.read_Req_resultFestival(t);
				ObservableList<String> festival_list2 = FXCollections.observableArrayList();
				festival_list.addAll(l);
				for(int i =0; i<l.size(); i++) {
					festival_list2.add(l.get(i).getFestival_name());
				}
				list.setItems(festival_list2);
			}
			else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("경고창");
				alert.setHeaderText("결과가 없습니다.");
				alert.setContentText("네트워크를 확인해주세요!");

				alert.showAndWait();
			}
		}
		else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("결과가 없습니다.");
			alert.setContentText("네트워크를 확인해주세요!");

			alert.showAndWait();
		}
	}
}
