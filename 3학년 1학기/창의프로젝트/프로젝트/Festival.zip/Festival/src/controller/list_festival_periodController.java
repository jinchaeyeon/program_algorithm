package controller;

import java.util.ArrayList;

import DTO.Festival;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import network.Network;

public class list_festival_periodController {

	@FXML
	private DatePicker start;

	@FXML
	private DatePicker end;

	@FXML
	private ListView<String> list;

	ObservableList<Festival> festival_list = FXCollections.observableArrayList();
	
	@FXML
	public void find(MouseEvent event) {
		try {
			festival_list.clear();
			list.refresh();
			String s = start.getValue().toString();
			String e = end.getValue().toString();
			if(s.isEmpty()) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("경고창");
				alert.setHeaderText("시작날짜를 선택하지 않았습니다.");
				alert.setContentText("시작날짜를 선택해주세요!");

				alert.showAndWait();
			}
			else if(e.isEmpty()) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("경고창");
				alert.setHeaderText("종료날짜를 선택하지 않았습니다.");
				alert.setContentText("종료날짜를 선택해주세요!");

				alert.showAndWait();
			}
			else {
				String [] arr = {s , e};
				ArrayList<Festival> l = Network.read_Req_Festival_period(arr);
				ObservableList<String> festival_list2 = FXCollections.observableArrayList();
				festival_list.addAll(l);
				for(int i =0; i<l.size(); i++) {
					festival_list2.add(l.get(i).getFestival_name());
				}
				list.setItems(festival_list2);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void choose(MouseEvent event) throws Exception{
		int index = list.getSelectionModel().getSelectedIndex();
		
		Festival f = new Festival();
		f= festival_list.get(index);
		FXMLLoader next = new FXMLLoader(getClass().getResource("/application/festival_info.fxml"));

		Parent root = next.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();

		fesitval_infoController pop = next.getController();
		pop.initData(f);
	}
}
