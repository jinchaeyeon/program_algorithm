package controller;

import java.math.BigInteger;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import network.Network;
import network.Protocol;

public class mypageupdateController implements Initializable{

	@FXML
	private AnchorPane mypage_update;

	@FXML
	private PasswordField pwd;

	@FXML
	private TextField number;

	@FXML
	private TextField address;

	@FXML
	private TextField age;

	@FXML
	private Label name;

	@FXML
	private Label id;

	@FXML
	private Label gender;

	@FXML
	private Label mbti;

	public void mypage_save(MouseEvent event) throws Exception {

		String Password = pwd.getText();
		String Phonenumber = number.getText();
		String Address = address.getText();
		String Age = age.getText();

		MessageDigest md = MessageDigest.getInstance("SHA-256");
		md.update(Password.getBytes());
		String hashpw = String.format("%064x", new BigInteger(1, md.digest()));

		MainController.getPerson().setPassword(hashpw);
		MainController.getPerson().setPhonenumber(Phonenumber);
		MainController.getPerson().setAddress(Address);
		MainController.getPerson().setAge(Integer.parseInt(Age));

		int result = Network.update_Req_User(MainController.getPerson());

		if(result == Protocol.UPDATE_RES_SUCCESS) {
			if(Password.isEmpty()) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("경고창");
				alert.setHeaderText("비밀번호를 입력하지 않았습니다.");
				alert.setContentText("비밀번호를 입력해주세요!");

				alert.showAndWait();
			}else if(Phonenumber.isEmpty()) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("경고창");
				alert.setHeaderText("전화번호를 입력하지 않았습니다.");
				alert.setContentText("전화번호를 입력해주세요!");

				alert.showAndWait();
			}else if(Address.isEmpty()) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("경고창");
				alert.setHeaderText("주소를 입력하지 않았습니다.");
				alert.setContentText("주소를 입력해주세요!");

				alert.showAndWait();
			}else if(Age.isEmpty()) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("경고창");
				alert.setHeaderText("나이를 입력하지 않았습니다.");
				alert.setContentText("나이를 입력해주세요!");

				alert.showAndWait();
			}
			else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("정보 저장");
				alert.setHeaderText("정보가 저장되었습니다!");
				alert.setContentText("즐거운 이용 바랍니다~");

				alert.showAndWait();

				Stage s = (Stage) mypage_update.getScene().getWindow();
				s.close();

				FXMLLoader next = new FXMLLoader(getClass().getResource("/application/mypage_info.fxml"));

				Parent root = next.load();
				Stage stage = new Stage();
				stage.setScene(new Scene(root));
				stage.show();
			}
		}
		else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("정보 저장 실패");
			alert.setHeaderText("정보가 저장되지 않았습니다 ㅠㅠ");
			alert.setContentText("네트워크를 확인해주세요");

			alert.showAndWait();
		}
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			MainController.setPerson(Network.read_Req_User(MainController.getPerson()));
			name.setText(MainController.getPerson().getName());
			id.setText(MainController.getPerson().getId());
			pwd.setText(MainController.getPerson().getPassword());
			number.setText(MainController.getPerson().getPhonenumber());
			address.setText(MainController.getPerson().getAddress());
			age.setText(Integer.toString(MainController.getPerson().getAge()));
			gender.setText(MainController.getPerson().getGender());
			mbti.setText(MainController.getPerson().getMbti());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
