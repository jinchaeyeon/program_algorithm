package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import DTO.Thumbs;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import network.Network;
import network.Protocol;

public class mypageinfoController implements Initializable {

	@FXML
	private AnchorPane mypage_info;

	@FXML
	private Label name;

	@FXML
	private Label id;

	@FXML
	private Label number;

	@FXML
	private Label address;

	@FXML
	private Label age;

	@FXML
	private Label gender;

	@FXML
	private Label mbti;

	public void mypage_update(MouseEvent event) throws IOException {
		Stage s = (Stage) mypage_info.getScene().getWindow();
		s.close();

		FXMLLoader root = new FXMLLoader(getClass().getResource("/application/mypage_update.fxml"));

		Parent root2 = root.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root2));
		stage.show();
	}

	@FXML
	void signout(MouseEvent event) throws Exception {
		int result = Network.delete_Req_User(MainController.getPerson());

		if(result == Protocol.DELETE_RES_SUCCESS) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("회원이 삭제됩니다.");
			alert.setContentText("감사합니다!");

			alert.showAndWait();
			Platform.exit();
		}
		else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("회원이 탈퇴되지 않았습니다");
			alert.setContentText("네트워크를 확인해주세요");

			alert.showAndWait();
		}
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		try {
			MainController.setPerson(Network.read_Req_User(MainController.getPerson()));
			name.setText(MainController.getPerson().getName());
			id.setText(MainController.getPerson().getId());
			number.setText(MainController.getPerson().getPhonenumber());
			address.setText(MainController.getPerson().getAddress());
			age.setText(Integer.toString(MainController.getPerson().getAge()));
			gender.setText(MainController.getPerson().getGender());
			mbti.setText(MainController.getPerson().getMbti());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	public void festival_listView(MouseEvent event) throws Exception {
		Thumbs t = new Thumbs();
		t.setUser_id(MainController.getPerson().geti());
		int result = Network.check_Req_IsThumbs(t);
		if(result == Protocol.CHECK_RES_SUCCESS) {
			FXMLLoader root = new FXMLLoader(getClass().getResource("/application/myfestival.fxml"));

			Parent root2 = root.load();
			Stage stage = new Stage();
			stage.setScene(new Scene(root2));
			stage.show();
		}
		else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("좋아요된 축제가 없습니다.");
			alert.setContentText("관심있는 축제정보를 좋아요눌러주세요!");

			alert.showAndWait();
		}
	}
}
