package controller;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;

import DTO.Festival;
import DTO.Thumbs;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import network.Network;
import network.Protocol;


public class fesitval_infoController {

	@FXML
	private ScrollPane scroll;

	@FXML
	private Label festival_name;

	@FXML
	private ImageView festival_image;

	@FXML
	private Label festival_start;

	@FXML
	private Label festival_final;

	@FXML
	private Label festival_address;

	@FXML
	private Label festival_detail;

	@FXML
	private Label festival_phonenumber;

	@FXML
	private Hyperlink festival_webaddress;

	Festival ff;

	public void initData(Festival f) {
		festival_name.setText(f.getFestival_name());
		festival_name.setWrapText(true);
		festival_name.setMaxWidth(190);
		festival_start.setText(f.getFestival_period_start());
		festival_final.setText(f.getFestival_period_final());
		festival_address.setText(f.getfestival_location());
		festival_detail.setText(f.getFestival_detail());
		festival_detail.setWrapText(true);
		festival_detail.setMaxWidth(330);
		festival_phonenumber.setText(f.getFestival_phonenumber());
		festival_webaddress.setText(f.getFestival_webaddress());
		festival_image.setImage(new Image(f.getFestival_image1()));
		festival_image.setPreserveRatio(true);
		ff = f;
	}


	public void webClick(MouseEvent event) throws URISyntaxException {
		try {
			Desktop.getDesktop().browse(new URL(festival_webaddress.getText()).toURI());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
	}

	@FXML
	public void reviewPage(MouseEvent event) throws Exception {
		try {		
			FXMLLoader next = new FXMLLoader(getClass().getResource("/application/review.fxml"));

			Parent root = next.load();
			Stage stage = new Stage();
			stage.setScene(new Scene(root));
			stage.show();

			reviewController pop = next.getController();
			pop.initData(ff);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@FXML
	public void mapsite(MouseEvent event) throws Exception {
		try {
			FXMLLoader next = new FXMLLoader(getClass().getResource("/application/map.fxml"));

			Parent root = next.load();
			Stage stage = new Stage();
			stage.setScene(new Scene(root));
			stage.show();

			mapController pop = next.getController();
			pop.initData(ff);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@FXML
	public void push(MouseEvent event) throws Exception {
		Thumbs t = new Thumbs();
		t.setFestival_id(ff.getI());
		t.setUser_id(MainController.getPerson().geti());
		if(MainController.isLogin() == true) {
			int re = Network.check_Req_Thumbs(t);
			if(re == Protocol.CHECK_RES_SUCCESS) {
				int result = Network.create_Req_Thumbs(t);
				if(result == Protocol.CREATE_RES_SUCCESS) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("성공");
					alert.setHeaderText("좋아요 +1");
					alert.setContentText("이 축제를 좋아해 주셔서 감사합니다~");

					alert.showAndWait();
				}
				else {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("경고창");
					alert.setHeaderText("실패하였습니다");
					alert.setContentText("네트워크를 확인해 주세요");

					alert.showAndWait();
				}
			}
			else {
				int result = Network.delete_Req_Thumbs(t);
				if(result == Protocol.DELETE_RES_SUCCESS) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("성공");
					alert.setHeaderText("삭제를 성공하였습니다.");
					alert.setContentText("다른 축제도 둘러봐 주세용!");

					alert.showAndWait();
				}
				else {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("경고창");
					alert.setHeaderText("실패하였습니다");
					alert.setContentText("네트워크를 확인해 주세요");

					alert.showAndWait();
				}
			}
		}
		else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("로그인 오류");
			alert.setContentText("로그인을 해주세요!");

			alert.showAndWait();
		}
	}
}
