package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import DTO.Festival;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import network.Network;

public class myfestivalController implements Initializable{

	@FXML
	private ListView<String> list;

	ObservableList<Festival> festival_list = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			festival_list.clear();
			ArrayList<Festival> l = Network.req_Req_Festival_By_Thumbs(MainController.getPerson());
			ObservableList<String> festival_list2 = FXCollections.observableArrayList();
			festival_list.addAll(l);
			for(int i =0; i<l.size(); i++) {
				festival_list2.add(l.get(i).getFestival_name());
			}
			list.setItems(festival_list2);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void choose(MouseEvent event) throws Exception{
		int index = list.getSelectionModel().getSelectedIndex();
		
		Festival f = new Festival();
		f= festival_list.get(index);
		FXMLLoader next = new FXMLLoader(getClass().getResource("/application/festival_info.fxml"));

		Parent root = next.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();

		fesitval_infoController pop = next.getController();
		pop.initData(f);
	}
}
