package controller;

import java.util.ArrayList;

import DTO.Festival;
import DTO.Review;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import network.Network;
import network.Protocol;

public class reviewController{

   @FXML
   private TextField text;

   @FXML
   private Button button;

   @FXML
   private TextField point;

   @FXML
   private TextField Title;

   @FXML
   private TableColumn<Review, Integer> star;

   @FXML
   private TableView<Review> tableview;

   @FXML
   private TableColumn<Review, String> title;

   @FXML
   private TableColumn<Review, String> writer;

   @FXML
   private TableColumn<Review, String> content;

   private ObservableList<Review> list = FXCollections.observableArrayList();

   Festival f = new Festival();

   @FXML
   public void delete(MouseEvent event) throws Exception {
      if(MainController.isLogin() == true) {
         Review deletereview = tableview.getSelectionModel().getSelectedItem();
         if (deletereview != null) {
            if(MainController.getPerson().getName().equals(deletereview.getWriter())) {
               int id = deletereview.getId();

               int result2 = Network.delete_Req_Review(id);

               if(result2 == Protocol.DELETE_RES_SUCCESS) {
                  initData(f);
               }
               else {
                  Alert alert = new Alert(AlertType.WARNING);
                  alert.setTitle("경고창");
                  alert.setHeaderText("삭제에 실패했습니다");
                  alert.setContentText("네트워크를 확인해주세요!");

                  alert.showAndWait();
               }
            }
            else {
               Alert alert = new Alert(AlertType.WARNING);
               alert.setTitle("경고창");
               alert.setHeaderText("해당 작성자가 아닙니다.");
               alert.setContentText("해당 작성자만 삭제 가능합니다!");

               alert.showAndWait();
            }
         }
         else {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("경고창");
            alert.setHeaderText("리뷰를 선택하지 않았습니다.");
            alert.setContentText("리뷰를 선택해주세요!");

            alert.showAndWait();
         }
      }
      else {
         Alert alert = new Alert(AlertType.WARNING);
         alert.setTitle("경고창");
         alert.setHeaderText("로그인이 필요합니다");
         alert.setContentText("로그인을 해주세요!");

         alert.showAndWait();
      }
   }


   @FXML
   public void register(MouseEvent event) throws Exception {
      if(MainController.isLogin() == true) {
         String t_title = Title.getText();
         String t_star= point.getText();
         String t_content = text.getText();

         if(t_title.isEmpty()) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("경고창");
            alert.setHeaderText("제목를 입력하지 않았습니다.");
            alert.setContentText("제목를 입력해주세요!");

            alert.showAndWait();
         }
         else if(t_star.isEmpty()) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("경고창");
            alert.setHeaderText("별점를 입력하지 않았습니다.");
            alert.setContentText("별점를 입력해주세요!");

            alert.showAndWait();
         }
         else if(t_content.isEmpty()) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("경고창");
            alert.setHeaderText("내용를 입력하지 않았습니다.");
            alert.setContentText("내용를 입력해주세요!");

            alert.showAndWait();
         }
         else if(Integer.parseInt(t_star) <= 0 || Integer.parseInt(t_star) > 5) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("경고창");
            alert.setHeaderText("별점은 최대 5입니다");
            alert.setContentText("다시 입력해주세요!");

            alert.showAndWait();
         }
         else {
            Review r = new Review();
            r.setFestival_id(f.getI());
            r.setTitle(t_title);
            r.setStar(Integer.parseInt(t_star));
            r.setContent(t_content);
            r.setWriter(MainController.getPerson().getName());

            int result2 = Network.create_Req_Review(r);

            if(result2 == Protocol.CREATE_RES_SUCCESS) {
               initData(f);
            }
            else {
               Alert alert = new Alert(AlertType.WARNING);
               alert.setTitle("경고창");
               alert.setHeaderText("등록에 실패했습니다");
               alert.setContentText("네트워크를 확인해주세요!");

               alert.showAndWait();
            }
         }
      }
      else {
         Alert alert = new Alert(AlertType.WARNING);
         alert.setTitle("경고창");
         alert.setHeaderText("로그인이 필요합니다");
         alert.setContentText("로그인을 해주세요!");

         alert.showAndWait();
      }
   }


   @FXML
   public void update(MouseEvent event) throws Exception {
      if(MainController.isLogin() == true) {
         if(Title.getText().isEmpty()) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("경고창");
            alert.setHeaderText("제목를 입력하지 않았습니다.");
            alert.setContentText("제목를 입력해주세요!");

            alert.showAndWait();
         }
         else if(point.getText().isEmpty()) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("경고창");
            alert.setHeaderText("별점를 입력하지 않았습니다.");
            alert.setContentText("별점를 입력해주세요!");

            alert.showAndWait();
         }
         else if(text.getText().isEmpty()) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("경고창");
            alert.setHeaderText("내용를 입력하지 않았습니다.");
            alert.setContentText("내용를 입력해주세요!");

            alert.showAndWait();
         }
         else {
            Review deletereview = tableview.getSelectionModel().getSelectedItem();
            if (deletereview != null) {
               if(MainController.getPerson().getName().equals(deletereview.getWriter())) {
                  String t_star= point.getText();
                  String t_title = Title.getText();
                  String t_content = text.getText();

                  if(Integer.parseInt(t_star) >= 0 && Integer.parseInt(t_star) <=5) {
                     Review r = new Review();
                     r.setStar(Integer.parseInt(t_star));
                     r.setTitle(t_title);
                     r.setContent(t_content);
                     r.setId(deletereview.getId());

                     int result2 = Network.update_Req_Review(r);

                     if(result2 == Protocol.UPDATE_RES_SUCCESS) {
                        initData(f);
                     }
                     else {
                        Alert alert = new Alert(AlertType.WARNING);
                        alert.setTitle("경고창");
                        alert.setHeaderText("수정에 실패했습니다");
                        alert.setContentText("네트워크를 확인해주세요!");

                        alert.showAndWait();
                     }
                  }
                  else {
                     Alert alert = new Alert(AlertType.WARNING);
                     alert.setTitle("경고창");
                     alert.setHeaderText("별점은 최대 5입니다");
                     alert.setContentText("다시 입력해주세요!");

                     alert.showAndWait();
                  }
               }
               else {
                  Alert alert = new Alert(AlertType.WARNING);
                  alert.setTitle("경고창");
                  alert.setHeaderText("해당 작성자가 아닙니다.");
                  alert.setContentText("해당 작성자만 수정 가능합니다!");

                  alert.showAndWait();
               }
            }
            else {
               Alert alert = new Alert(AlertType.WARNING);
               alert.setTitle("경고창");
               alert.setHeaderText("리뷰를 선택하지 않았습니다.");
               alert.setContentText("리뷰를 선택해주세요!");

               alert.showAndWait();
            }
         }
      }
      else {
         Alert alert = new Alert(AlertType.WARNING);
         alert.setTitle("경고창");
         alert.setHeaderText("로그인이 필요합니다");
         alert.setContentText("로그인을 해주세요!");

         alert.showAndWait();
      }
   }      

   public void initData(Festival ff) {
      list.clear();
      tableview.refresh();

      f.setI(ff.getI());
      title.setCellValueFactory(new PropertyValueFactory<>("title"));
      writer.setCellValueFactory(new PropertyValueFactory<>("writer"));
      star.setCellValueFactory(new PropertyValueFactory<>("star"));
      content.setCellValueFactory(new PropertyValueFactory<>("content"));

      try {
         ArrayList<Review> r = Network.read_Req_Review(ff.getI());
         ObservableList<Review> reviews = FXCollections.observableArrayList();

         for(int i =0; i<r.size(); i++) {
            reviews.add(r.get(i));
         }
         list.addAll(r);

      } catch (Exception e) {
         e.printStackTrace();
      }

      tableview.setItems(list);
   }
}