package controller;

import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;

import DTO.Person;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import network.Network;
import network.Protocol;

public class LoginController {

   @FXML
   private AnchorPane loginfield;

   @FXML
   private TextField id;

   @FXML
   private PasswordField password;

   @FXML
   public void login(MouseEvent event) throws Exception {
      String ID = id.getText();
      String PASSWORD = password.getText();

      Person p = new Person();

      if(ID.isEmpty()) {
         Alert alert = new Alert(AlertType.WARNING);
         alert.setTitle("경고창");
         alert.setHeaderText("아이디를 입력하지 않았습니다.");
         alert.setContentText("아이디를 입력해주세요!");

         alert.showAndWait();
      }
      else if(PASSWORD.isEmpty()) {
         Alert alert = new Alert(AlertType.WARNING);
         alert.setTitle("경고창");
         alert.setHeaderText("비밀번호를 입력하지 않았습니다.");
         alert.setContentText("비밀번호를 입력해주세요!");

         alert.showAndWait();
      }
      else {
    	 MessageDigest md = MessageDigest.getInstance("SHA-256");
         md.update(PASSWORD.getBytes());
         String hashpw = String.format("%064x", new BigInteger(1, md.digest()));

         p.setId(ID);
         p.setPassword(hashpw);
         int result = Network.login(p);

         if(result == Protocol.LOGIN_RES_SUCCESS) {   
            MainController.setPerson(Network.read_Req_User(p));
            
            FXMLLoader root2 = new FXMLLoader(getClass().getResource("/application/login_info.fxml"));
            AnchorPane newPane = root2.load();
            loginfield.getChildren().setAll(newPane);

            AnchorPane.setBottomAnchor(newPane, 0.0);
            AnchorPane.setLeftAnchor(newPane, 0.0);
            AnchorPane.setRightAnchor(newPane, 0.0);
            AnchorPane.setTopAnchor(newPane, 0.0);
            MainController.isSetLogin(true);
         }
         else if(result == Protocol.LOGIN_RES_NO_ID){
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("경고창");
            alert.setHeaderText("아이디가 틀렸습니다.");
            alert.setContentText("아이디를 다시 입력해주세요!");

            alert.showAndWait();
         }
         else if(result == Protocol.LOGIN_RES_NO_PASSWD){
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("경고창");
            alert.setHeaderText("비밀번호가 틀렸습니다.");
            alert.setContentText("비밀번호를 다시 입력해주세요!");

            alert.showAndWait();
         }
         else {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("경고창");
            alert.setHeaderText("로그인에 실패했습니다");
            alert.setContentText("네트워크를 확인해주세요");

            alert.showAndWait();
         }
      }
   }

   @FXML
   public void signin(MouseEvent event) throws IOException{
      try {
         FXMLLoader next = new FXMLLoader(getClass().getResource("/application/signin.fxml"));

         Parent root = next.load();
         Stage stage = new Stage();
         stage.setScene(new Scene(root));
         stage.show();
      } catch (Exception e) {
         e.printStackTrace();
      }
   }
}