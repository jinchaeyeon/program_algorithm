package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import DTO.Person;
import DTO.Tag;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import network.Network;

public class mbtiwaitController {

	@FXML
	private AnchorPane mbti_wait;

	@FXML
	private Label test_count;

	Person person = new Person();
	
	@FXML
	public void tag(MouseEvent event) throws IOException {
		Stage s = (Stage) mbti_wait.getScene().getWindow();
		s.close();

		try {
			ArrayList<Tag> t = Network.read_Req_Tag(person.getMbti());
			
			Tag [] arr = new Tag[t.size()];
			
			for(int i=0; i<t.size(); i++) {
				arr[i] = new Tag(t.get(i).getName());
			}
			
			FXMLLoader next = new FXMLLoader(getClass().getResource("/application/checktag.fxml"));
			Parent root = next.load();
			checktagController c = next.getController();
			c.setting(arr);
			Stage stage = new Stage();
			stage.setScene(new Scene(root));
			stage.show();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void initData(Person p) {
		person.setMbti(p.getMbti());
	}
}
