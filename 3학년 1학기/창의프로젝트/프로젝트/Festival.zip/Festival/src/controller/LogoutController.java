package controller;

import java.net.URL;
import java.util.ResourceBundle;

import DTO.Person;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import network.Network;

public class LogoutController implements Initializable{

   @FXML
   private AnchorPane login_info;

   @FXML
   private Label name;

   @FXML
   void logout(MouseEvent event) throws Exception {
      boolean result = Network.logout(MainController.getPerson());

      if(result == true) {
    	 MainController.isSetLogin(false);
         MainController.setPerson(new Person());
         FXMLLoader root = new FXMLLoader(getClass().getResource("/application/login.fxml"));
         AnchorPane newPane = root.load();
         login_info.getChildren().setAll(newPane);

         AnchorPane.setBottomAnchor(newPane, 0.0);
         AnchorPane.setLeftAnchor(newPane, 0.0);
         AnchorPane.setRightAnchor(newPane, 0.0);
         AnchorPane.setTopAnchor(newPane, 0.0);
        
      }
      else {
         Alert alert = new Alert(AlertType.WARNING);
         alert.setTitle("경고창");
         alert.setHeaderText("로그아웃이 안되었습니다");
         alert.setContentText("네트워크를 확인해주세요");

         alert.showAndWait();
      }
   }

   @FXML
   void mypage(MouseEvent event) throws Exception {
      FXMLLoader next = new FXMLLoader(getClass().getResource("/application/mypage_info.fxml"));

      Parent root = next.load();
      Stage stage = new Stage();
      stage.setScene(new Scene(root));
      stage.show();
   }

   public void initialize(URL arg0, ResourceBundle arg1) {
      name.setText(MainController.getPerson().getName());
   }
}