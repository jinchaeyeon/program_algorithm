package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import DTO.Festival;
import DTO.Person;
import DTO.mbtiTree;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import network.Network;
import network.Protocol;

public class MainController implements Initializable{

   private ObservableList<Festival> list = FXCollections.observableArrayList();

   @FXML
   private AnchorPane Menu;

   @FXML
   private AnchorPane login_box;

   @FXML
   private ListView<String> festival_list;

   static Person p = new Person();
   static mbtiTree m = new mbtiTree();

   public static Person getPerson() {
      return p;
   }

   public static void setPerson(Person p2) {
      p = p2;
   }

   public static mbtiTree getTree() {
      return m;
   }

   static Festival f = new Festival();

   public static Festival getfestival() {
      return f;
   }

   public static Festival setfestival(Festival f) {
      f = null;
      return f;
   }
   
   static boolean b = false;
   
   public static boolean isLogin() {
      return b;
   }
   
   public static void isSetLogin(boolean a) {
      b = a;
   }

   @Override
   public void initialize(URL arg0, ResourceBundle arg1) {
      try {
         FXMLLoader root = new FXMLLoader(getClass().getResource("/application/login.fxml"));
         AnchorPane newPane = root.load();
         login_box.getChildren().setAll(newPane);

         AnchorPane.setBottomAnchor(newPane, 0.0);
         AnchorPane.setLeftAnchor(newPane, 0.0);
         AnchorPane.setRightAnchor(newPane, 0.0);
         AnchorPane.setTopAnchor(newPane, 0.0);

         ArrayList<Festival> l = Network.read_Req_Statistic_Rank_Star();
         ObservableList<String> festival_list2 = FXCollections.observableArrayList();
         list.addAll(l);
         for(int i =0; i<10; i++) {
            if(i == l.size()) {
               break;
            }
            else{
               festival_list2.add(l.get(i).getFestival_name());
            }
         }
         festival_list.setItems(festival_list2);

      } catch (IOException e) {
         e.printStackTrace();
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   public void choose(MouseEvent event) throws Exception{

      int index = festival_list.getSelectionModel().getSelectedIndex();

      Festival f = new Festival();
      f= list.get(index);
      FXMLLoader next = new FXMLLoader(getClass().getResource("/application/festival_info.fxml"));

      Parent root = next.load();
      Stage stage = new Stage();
      stage.setScene(new Scene(root));
      stage.show();

      fesitval_infoController pop = next.getController();
      pop.initData(f);

   }

   @FXML
   public void choose_period(MouseEvent event) throws IOException {
      FXMLLoader next = new FXMLLoader(getClass().getResource("/application/list_festival_period.fxml"));

      Parent root = next.load();
      Stage stage = new Stage();
      stage.setScene(new Scene(root));
      stage.show();

   }

   public void handlelistPeriod(MouseEvent event) throws Exception {
      FXMLLoader next = new FXMLLoader(getClass().getResource("/application/list_festival.fxml"));

      Parent root = next.load();
      Stage stage = new Stage();
      stage.setScene(new Scene(root));
      stage.show();
   }

   public void handleMbtiTestAction(MouseEvent event) throws Exception {
      
      if(b == true) {
         m = new mbtiTree();
         FXMLLoader next = new FXMLLoader(getClass().getResource("/application/mbti_test.fxml"));

         Parent root = next.load();
         Stage stage = new Stage();
         stage.setScene(new Scene(root));
         stage.show();

         m.start();
         mbtitestController pop = next.getController();
         pop.initData(getTree().getRoot());
         p.setMbti("");
      }
      else {
         Alert alert = new Alert(AlertType.WARNING);
         alert.setTitle("경고창");
         alert.setHeaderText("로그인이 필요합니다");
         alert.setContentText("로그인을 해주세요!");

         alert.showAndWait();
      }
   }

   public void close(MouseEvent event) throws Exception {
      setPerson(null);
      Platform.exit();
   }
}