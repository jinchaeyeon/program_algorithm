package controller;

import java.io.IOException;
import java.net.URL;

import javax.script.ScriptException;

import DTO.Festival;

import javafx.fxml.FXML;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import netscape.javascript.JSObject;

public class mapController{

	@FXML
	private WebView map;

	public void initData(Festival f) throws IOException, ScriptException, NoSuchMethodException {
		WebEngine webEngine = map.getEngine();
		final URL urlKakaoMaps = getClass().getResource("map.html");
		
		webEngine.load(urlKakaoMaps.toExternalForm());
		
	 	JSObject j = (JSObject) webEngine.executeScript("window");
	 	j.setMember("Festival", f);
	}
}