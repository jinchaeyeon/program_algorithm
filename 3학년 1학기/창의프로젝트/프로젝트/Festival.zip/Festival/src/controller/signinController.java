package controller;

import java.math.BigInteger;
import java.security.MessageDigest;

import DTO.Person;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import network.Network;

public class signinController {

	@FXML
	private AnchorPane signin;

	@FXML
	private TextField person_name;

	@FXML
	private TextField person_id;

	@FXML
	private PasswordField person_password;

	@FXML
	private TextField person_phonenumber;

	@FXML
	private TextField person_address;

	@FXML
	private TextField person_age;

	@FXML
	private RadioButton person_gender_m;

	@FXML
	private RadioButton person_gender_w;

	@FXML
	public void register(MouseEvent event) throws Exception {
		String Name = person_name.getText();
		String Id = person_id.getText();
		String Password = person_password.getText();
		String Phonenumber = person_phonenumber.getText();
		String Address = person_address.getText();
		String Age = person_age.getText();
		
		Person p = new Person();

		if(Name.isEmpty()) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("이름를 입력하지 않았습니다.");
			alert.setContentText("이름를 입력해주세요!");

			alert.showAndWait();
		}
		else if(Id.isEmpty()) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("아이디를 입력하지 않았습니다.");
			alert.setContentText("아이디를 입력해주세요!");

			alert.showAndWait();
		}
		else if(Password.isEmpty()) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("비밀번호를 입력하지 않았습니다.");
			alert.setContentText("비밀번호를 입력해주세요!");

			alert.showAndWait();
		}else if(Phonenumber.isEmpty()) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("전화번호를 입력하지 않았습니다.");
			alert.setContentText("전화번호를 입력해주세요!");

			alert.showAndWait();
		}else if(Address.isEmpty()) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("주소를 입력하지 않았습니다.");
			alert.setContentText("주소를 입력해주세요!");

			alert.showAndWait();
		}else if(Age.isEmpty()) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("나이를 입력하지 않았습니다.");
			alert.setContentText("나이를 입력해주세요!");

			alert.showAndWait();
		}
		else if(!(person_gender_m.isSelected() || person_gender_w.isSelected())){
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고창");
			alert.setHeaderText("성별을 체크하지 않았습니다.");
			alert.setContentText("성별을 체크해주세요!");

			alert.showAndWait();
		}
		else {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(Password.getBytes());
			String hashpw = String.format("%064x", new BigInteger(1, md.digest()));
			
			p.setName(Name);
			p.setId(Id);
			p.setPassword(hashpw);
			p.setPhonenumber(Phonenumber);
			p.setAddress(Address);
			p.setAge(Integer.parseInt(Age));

			if(person_gender_m.isSelected()) {
				p.setGender("남");
			}
			else if(person_gender_w.isSelected()) {
				p.setGender("여");
			}

			int result = Network.check_Req_Id(p);
			Alert alert = new Alert(AlertType.WARNING);
			if(result == 1) {
				int result_sign_up = Network.create_Req_User(p);
				if(result_sign_up == 1) {
					alert.setTitle("가입 성공");
					alert.setHeaderText("가입이 성공적으로 완료되었습니다.");
					alert.setContentText("환영합니다!");

					alert.showAndWait();
					Stage stage = (Stage) signin.getScene().getWindow();
					stage.close();
				}
				else {
					alert.setTitle("가입 실패");
					alert.setHeaderText("가입이 실패하였습니다.");
					alert.setContentText("네트워크를 확인해주세요");

					alert.showAndWait();
					Stage stage = (Stage) signin.getScene().getWindow();
					stage.close();
				}
			}
			else {
				alert.setTitle("가입 실패");
				alert.setHeaderText("가입이 실패하였습니다.");
				alert.setContentText("아이디가 중복입니다");

				alert.showAndWait();
				Stage stage = (Stage) signin.getScene().getWindow();
				stage.close();
			}	
		}
	}
}
