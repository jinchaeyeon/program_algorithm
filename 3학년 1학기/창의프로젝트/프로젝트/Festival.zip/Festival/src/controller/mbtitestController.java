package controller;

import DTO.mbtiNode;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import network.Network;

public class mbtitestController {

	@FXML
	private AnchorPane mbti_test;

	@FXML
	private Label a1;

	@FXML
	private Label a2;

	@FXML
	private RadioButton one;

	@FXML
	private TextArea q;

	@FXML
	private ToggleGroup question;

	@FXML
	private RadioButton two;
	
	public void handleMbtiNextAction(MouseEvent event) throws Exception {
		try {
			if(one.isSelected() || two.isSelected()) {
				if(MainController.getTree().height(MainController.getTree().getRoot()) == 2) {
					if(one.isSelected()) {
						MainController.getTree().setRoot(MainController.getTree().getRoot().getLeft());
					}
					else {
						MainController.getTree().setRoot(MainController.getTree().getRoot().getRight());
					}
					Stage s = (Stage) mbti_test.getScene().getWindow();
					s.close();
				}
				else if(one.isSelected()) {
					MainController.getTree().setRoot(MainController.getTree().getRoot().getLeft());

					Stage s = (Stage) mbti_test.getScene().getWindow();
					s.close();

					FXMLLoader next = new FXMLLoader(getClass().getResource("/application/mbti_test.fxml"));

					Parent root = next.load();
					Stage stage = new Stage();
					stage.setScene(new Scene(root));
					stage.show();

					mbtitestController pop = next.getController();
					pop.initData(MainController.getTree().getRoot());
				}
				else if(two.isSelected()) {
					MainController.getTree().setRoot(MainController.getTree().getRoot().getRight());

					Stage s = (Stage) mbti_test.getScene().getWindow();
					s.close();

					FXMLLoader next = new FXMLLoader(getClass().getResource("/application/mbti_test.fxml"));

					Parent root = next.load();
					Stage stage = new Stage();
					stage.setScene(new Scene(root));
					stage.show();

					mbtitestController pop = next.getController();
					pop.initData(MainController.getTree().getRoot());
				}	
				String temp = MainController.getPerson().getMbti();
				MainController.getPerson().setMbti(temp+MainController.getTree().getRoot().getMbti());
				if(MainController.getPerson().getMbti().length() == 4) {
					Network.update_Req_User(MainController.getPerson());
					
					FXMLLoader next = new FXMLLoader(getClass().getResource("/application/mbti_wait.fxml"));

					Parent root = next.load();
					Stage stage = new Stage();
					stage.setScene(new Scene(root));
					stage.show();
					
					mbtiwaitController pop = next.getController();
					pop.initData(MainController.getPerson());
				}
			}
			else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("경고창");
				alert.setHeaderText("문답을 선택하지 않았습니다.");
				alert.setContentText("문답을 선택해주세요!");

				alert.showAndWait();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void initData(mbtiNode n) {
		q.setText(n.getItem());
		a1.setText(n.getAns1());
		a2.setText(n.getAns2());
	}
}