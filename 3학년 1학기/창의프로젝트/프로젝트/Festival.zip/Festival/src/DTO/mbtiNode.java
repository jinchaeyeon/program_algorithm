package DTO;

public class mbtiNode {
		private String item;
		private String mbti;
		private mbtiNode left;
		private mbtiNode right;
		private String ans1;
		private String ans2;
		private int key;
		
		public mbtiNode(String i, String m, String a1, String a2, int k) {
			item = i;
			mbti = m;
			ans1 = a1;
			ans2 = a2;
			left = null;
			right = null;
			key = k;
		}
		
		public String getMbti() {return mbti;}
		public void setMbti(String mbti) {this.mbti = mbti;}
		public int getkey() {return key;}
		public void setkey(int key) {this.key = key;}
		public String getItem() {return item;}
		public void setItem(String item) {this.item = item;}
		public mbtiNode getLeft() {return left;}
		public void setLeft(mbtiNode left) {this.left = left;}
		public mbtiNode getRight() {return right;}
		public void setRight(mbtiNode right) {this.right = right;}
		public String getAns1() {return ans1;}
		public void setAns1(String ans1) {this.ans1 = ans1;}
		public String getAns2() {return ans2;}
		public void setAns2(String ans2) {this.ans2 = ans2;}
}
