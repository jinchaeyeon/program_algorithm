package DTO;

public class mbtiTree {
	private mbtiNode root;
	
	public mbtiTree() {root = null;}
	public mbtiNode getRoot() { return root;}
	public void setRoot(mbtiNode newRoot) { root = newRoot;}
	public boolean isEmpty() { return root == null;}
	
    public int height(mbtiNode root) {
    	if(root == null) {return 0;}
    	else {
    		return (1+Math.max(height(root.getLeft()), height(root.getRight())));
    	}
    }
    
	public void insert(String i, String m, String a1, String a2, int k) {
		mbtiNode newNode = new mbtiNode(i,m,a1,a2,k);
		
		if(root == null) {
			root = newNode;
			return;
		}
		mbtiNode current = root;
		mbtiNode parent = null;
		
		while(true) {
			parent = current;
			if(k < current.getkey()) {
				current = current.getLeft();
				if(current == null) {
					parent.setLeft(newNode);
					return;
				}
			}
			else {
				current = current.getRight();
				if(current ==null) {
					parent.setRight(newNode);
					return;
				}
			}
		}
	}
	
	public void start() {
		insert("축제는 혼자보단 여럿이서 가는게 좋습니까?",null, "네","아니오" ,16);
		insert("보통 일행 중 미성년자가 있습니까?","T","네","아니오",8);
		insert("당신의 나이가 20살 미만입니까?","S","네","아니오",24);
		insert("눈 앞에 바다가 보입니다. 어찌하겠습니까?","L", "뛰어들어서 논다.","바다 경치를 구경한다.",4);
		insert("댄스파티에 있습니다. 어찌 하겠습니까?","U","같이 춤을 추며 즐긴다.", "멀리서 구경한다.",12);
		insert("노래를 들으면서 밤산책 중 친구가 같이 운동하자고 합니다.하시겠습니까?","L","네","아니오",20);
		insert("영화를 보며 맥주를 먹는 중 친구가 게임를 하자 합니다. 하시겠습니까?","U","네","아니오",28);
		insert("친구들과 뛰어논 뒤 당신은 무엇을 하겠습니까?","A","노을진 바다를 보며 걷는다","사진찍으러 돌아다닌다.",2);
		insert("바다를 구경한 뒤 당신은 무엇을 하겠습니까?","P","노을진 바다를 보며 걷는다","사진찍으러 돌아다닌다.",6);
		insert("댄스파티가 끝난 후 당신은 무엇을 하겠습니까?","A", "맥주한캔을 먹으러 간다", "친구들과 수다를 떨면서 거리를 걷는다.",10);
		insert("퍼레이드를 관람한 후 당신은 무엇을 하겠습니까?","P","친구들과 소주 한잔을 하러 간다.", "친구들과 같이 드라이브를 한다.",14);
		insert("친구와 운동 후  무엇을 하겠습니까?","A", "맥주한캔을 한다","수다를 떨면서 더 걷는다.",18);
		insert("노래를 들으며 산책을 하는데 앞에 강아지와 무엇을 하시겠습니까?","P", "쓰담아 준다.", "같이 산책한다.",22);
		insert("친구와의 젠가 게임에서 졌습니다.벌칙은 어떤게 좋습니까?","A", "노래부르기", "춤추기",26);
		insert("영화를 본 후 산책을 나가는데 친구들이 집앞에서 모여있습니다.무슨 분위기 입니까?","P", "조용한 분위기", "시끌벅적한 분위기",30);
		insert(null,"C",null,null,1);
		insert(null,"E",null,null,3);
		insert(null,"C",null,null,5);
		insert(null,"E",null,null,7);
		insert(null,"C",null,null,9);
		insert(null,"E",null,null,11);
		insert(null,"C",null,null,13);
		insert(null,"E",null,null,15);
		insert(null,"C",null,null,17);
		insert(null,"E",null,null,19);
		insert(null,"C",null,null,21);
		insert(null,"E",null,null,23);
		insert(null,"C",null,null,25);
		insert(null,"E",null,null,27);
		insert(null,"C",null,null,29);		
		insert(null,"E",null,null,31);
	}
}
