package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DAOHandler
{
    public static Connection getConnection() {
        Connection conn = null;
        try {
            String user = "root";
            String pw = "esj5029";
            String url = "jdbc:mysql://localhost:3306/festival_db?serverTimezone=UTC";

            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, pw);
            System.out.println("DB 연결 성공");

        } catch (ClassNotFoundException cnfe) {
            System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
        } catch (SQLException sqle) {
            System.out.println("DB 접속실패 : " + sqle.toString());
        } catch (Exception e) {
            System.out.println("Unkonwn error");
            e.printStackTrace();
        }
        return conn;
    }
}

