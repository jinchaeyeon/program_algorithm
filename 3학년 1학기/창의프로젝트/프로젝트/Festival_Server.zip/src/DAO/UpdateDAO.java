package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DTO.Person;
import DTO.Review;
import network.Protocol;

public class UpdateDAO {
	public UpdateDAO() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException cnfe) {
			System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
		}
	}

	public static int updateUser(Person p)
	{
		Connection conn = null;
		PreparedStatement pstmt = null;

		String pwd = p.getPassword();
		String phonenumber = p.getPhonenumber();
		String address = p.getAddress();
		int age = p.getAge();
		int i = p.geti();
		String mbti = p.getMbti();

		String SQL = "UPDATE person SET login_password = ? , phonenumber = ?, address = ?, age = ? where id = ?";
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setString(1, pwd);
			pstmt.setString(2, phonenumber);
			pstmt.setString(3, address);
			pstmt.setInt(4, age);
			pstmt.setInt(5, i);
			
			pstmt.executeUpdate();
			return Protocol.UPDATE_RES_SUCCESS;

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			return Protocol.UPDATE_RES_FAIL;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	}

	public static int updateReview(Review r) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String title = r.getTitle();
		int star = r.getStar();
		String content = r.getContent();

		String SQL = "UPDATE review SET title = ? , star = ?, content = ? where id = ?";
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setString(1, title);
			pstmt.setInt(2, star);
			pstmt.setString(3, content);
			pstmt.setInt(4, r.getId());
			pstmt.executeUpdate();
			return Protocol.UPDATE_RES_SUCCESS;

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			return Protocol.UPDATE_RES_FAIL;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	}

	public static int updateUserCount(Person p) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String SQL = "UPDATE PERSON " + "SET TEST_COUNT = TEST_COUNT + 1, " + "MBTI = ? " + "WHERE ID = ?;";
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);
			
			Connection con2 = null;
			PreparedStatement pstm2 = null;
			
			String SQL3 = "SELECT * FROM mbti where name = ?";
			
			con2 = DAOHandler.getConnection();
			pstm2 = con2.prepareStatement(SQL3);
			
			pstm2.setString(1,p.getMbti());
			ResultSet r2 = pstm2.executeQuery();
			if(r2.next()) {
				pstmt.setInt(1, r2.getInt("id"));
			}
			
			pstmt.setInt(2, p.geti());

			pstmt.executeUpdate();
			return Protocol.UPDATE_RES_SUCCESS;
		}catch (SQLException sqle) {
			sqle.printStackTrace();
			return Protocol.UPDATE_RES_FAIL;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	}

	public static int updateMbti(String mbti) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String SQL = "UPDATE MBTI " + "SET COUNT = COUNT + 1 " + "WHERE NAME = ?;";
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, mbti);
			pstmt.executeUpdate();
			return Protocol.UPDATE_RES_SUCCESS;
		}catch (SQLException sqle) {
			sqle.printStackTrace();
			return Protocol.UPDATE_RES_FAIL;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	}
}
