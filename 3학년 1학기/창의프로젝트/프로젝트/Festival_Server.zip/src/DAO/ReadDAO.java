package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import DTO.Festival;
import DTO.Person;
import DTO.Review;
import DTO.Tag;
import network.Protocol;

public class ReadDAO {
	public ReadDAO() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException cnfe) {
			System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
		}
	}

	public static Person readUser(Person p)
	{
		Person person = new Person();
		Connection conn = null;
		PreparedStatement pstmt = null;

		String SQL = "SELECT * FROM person where login_id = ?";

		Connection conn2 = null;
		PreparedStatement pstmt2 = null;
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setString(1,p.getId());
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) { 
				person.seti(rs.getInt("id"));
				person.setName(rs.getString("name"));
				person.setAddress(rs.getString("address"));
				person.setAge(rs.getInt("age"));
				person.setGender(rs.getString("gender"));
				person.setId(rs.getString("login_id"));

				String SQL2 = "SELECT * FROM mbti where id = ?";

				conn2 = DAOHandler.getConnection();
				pstmt2 = conn2.prepareStatement(SQL2);

				pstmt2.setInt(1,rs.getInt("mbti"));
				ResultSet rs2 = pstmt2.executeQuery();
				if(rs2.next()) {
					person.setMbti(rs2.getString("name"));
				}
				person.setPassword(rs.getString("login_password"));
				person.setPhonenumber(rs.getString("phonenumber"));
			}

			return person;
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return person;
	}

	public static ArrayList<Festival> readFestivalList(Festival f)
	{
		Connection conn = null;
		PreparedStatement pstmt = null;

		String SQL = "SELECT * FROM festival where local_area = ?";

		ArrayList<Festival> list = new ArrayList<>();

		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setString(1,f.getFestival_local_area());
			ResultSet rs = pstmt.executeQuery();

			System.out.println(f.getFestival_local_area());

			while(rs.next()) {
				Connection conn2 = null;
				PreparedStatement pstmt2 = null;

				Festival new_f = new Festival();
				new_f.setI(rs.getInt("id"));
				new_f.setFestival_name(rs.getString("name"));
				new_f.setFestival_local_area(rs.getString("local_area"));
				new_f.setfestival_location(rs.getString("location"));
				new_f.setFestival_phonenumber(rs.getString("phone_number"));

				String SQL2 = "SELECT * FROM mbti where id = ?";

				conn2 = DAOHandler.getConnection();
				pstmt2 = conn2.prepareStatement(SQL2);

				pstmt2.setInt(1,rs.getInt("mbti"));
				ResultSet rs2 = pstmt2.executeQuery();
				if(rs2.next()) {
					new_f.setFestival_mbti(rs2.getString("name"));
				}

				new_f.setFestival_image1(rs.getString("image_URL"));
				new_f.setFestival_detail(rs.getString("detail"));
				new_f.setFestival_webaddress(rs.getString("web_address"));
				new_f.setTag(rs.getString("tag"));
				new_f.setFestival_period_start(rs.getString("period_start"));
				new_f.setFestival_period_final(rs.getString("period_final"));
				new_f.setX(rs.getDouble("x"));
				new_f.setY(rs.getDouble("y"));
				list.add(new_f);
			}
			return list;
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return list;
	}

	public static ArrayList<Review> readReview(int id)
	{
		Connection conn = null;
		PreparedStatement pstmt = null;

		String SQL = "SELECT id,title,name,star,content,festival_id FROM Review where festival_id = ?";
		ArrayList<Review> list = new ArrayList<>();
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setInt(1,id);
			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {
				Review r = new Review();
				r.setId(rs.getInt("id"));
				r.setTitle(rs.getString("title"));
				r.setWriter(rs.getString("name"));
				r.setStar(rs.getInt("star"));
				r.setContent(rs.getString("content"));
				r.setFestival_id(rs.getInt("festival_id"));
				list.add(r);
			}
			return list;
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return list;
	}

	public static ArrayList<Tag> readTag(String mbti) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String SQL = "SELECT TAG FROM FESTIVAL WHERE MBTI=?;";
		ArrayList<Tag> t_list = new ArrayList<Tag>();
		try {
			Connection conn2 = null;
			PreparedStatement pstmt2 = null;

			String SQL2 = "SELECT * FROM mbti where name = ?";

			conn2 = DAOHandler.getConnection();
			pstmt2 = conn2.prepareStatement(SQL2);

			int mbti_str = 0;

			pstmt2.setString(1,mbti);
			ResultSet rs2 = pstmt2.executeQuery();
			if(rs2.next()) {
				mbti_str = rs2.getInt("id");
			}

			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setInt(1, mbti_str);
			ResultSet rs = pstmt.executeQuery();

			ArrayList<String> s_list = new ArrayList<String>();
			while (rs.next()) {
				String tag = rs.getString(1);
				String[] temp = tag.split("/");
				for (int i = 0; i < temp.length; i++) {
					if (temp[i].equals("프로그램") || temp[i].equals("행사") || temp[i].equals("축제")
							|| temp[i].equals("페스티벌")) {
					} else {
						if (!s_list.contains(temp[i])) {
							s_list.add(temp[i]);
						}
					}
				}
			}
			Collections.sort(s_list);

			for (int i = 0; i < s_list.size(); i++) {
				String tag_Name = s_list.get(i);
				Tag t = new Tag(tag_Name);
				t_list.add(t);
			}
			return t_list;
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return t_list;
	}

	public static ArrayList<Festival> result_Festival(Tag [] t) throws SQLException{
		Connection conn = null;
		PreparedStatement pstmt = null;

		Connection con = null;
		PreparedStatement pstm = null;

		String SQL2 = "SELECT * FROM mbti where name = ?";

		con = DAOHandler.getConnection();
		pstm = con.prepareStatement(SQL2);

		int mbti_str = 0;

		pstm.setString(1,t[0].getName());
		ResultSet r = pstm.executeQuery();
		if(r.next()) {
			mbti_str = r.getInt("id");
		}

		// tag의 개수에 따른 동적 sql문 생성과 실행
		StringBuilder sb2 = new StringBuilder();
		sb2.append("SELECT id, tag, mbti FROM festival where mbti = '" + mbti_str + "' and (tag like '%" + t[1].getName()
				+ "%'");
		for (int i = 2; i < t.length; i++) {
			sb2.append(" or tag like '%" + t[i].getName() + "%'");
		}
		sb2.append(")");

		ArrayList<Festival> list = new ArrayList<Festival>();
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(sb2.toString());
			ResultSet rs = pstmt.executeQuery();

			PreparedStatement pstmt2 = conn.prepareStatement(sb2.toString());
			ResultSet rs2 = pstmt2.executeQuery();

			int rowcount = 0;

			while(rs2.next()) {
				rowcount++;
			}

			int idx = 0; //해당 조건을 만족하는 festival 객체의 개수
			String[][] festival = new String[rowcount][3]; //해당 조건을 만족하는 festival의 id, tag, count를 담을 이차원배열

			while(rs.next()) {
				festival[idx][0] = rs.getString("id");
				festival[idx][1] = rs.getString("tag");

				int sum = 0;
				for (int i=1; i<t.length-1; i++) {
					if (festival[idx][1].contains(t[i].getName())) {
						sum++;
					}
				}
				festival[idx][2] = Integer.toString(sum);     

				idx++;
			}

			for (int i = 1; i < rowcount; i++) {
				for (int j = 0; j < rowcount-i; j++) {
					if (!isless(festival[j][2], festival[j + 1][2])) {
						swap(festival, j, j + 1);
					}
				}
			} 

			for (int i = 0; i < 10; i++) {
				if(i == festival.length) {
					break;
				}else {
					String sql = "SELECT * FROM festival where id = " + Integer.parseInt(festival[i][0]) + ";";
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();

					while(rs.next()) {
						Festival new_f = new Festival();
						new_f.setI(rs.getInt("id"));
						new_f.setFestival_name(rs.getString("name"));
						new_f.setFestival_local_area(rs.getString("local_area"));
						new_f.setfestival_location(rs.getString("location"));
						new_f.setFestival_phonenumber(rs.getString("phone_number"));

						Connection con2 = null;
						PreparedStatement pstm2 = null;

						String SQL3 = "SELECT * FROM mbti where id = ?";

						con2 = DAOHandler.getConnection();
						pstm2 = con2.prepareStatement(SQL3);

						pstm2.setInt(1,rs.getInt("mbti"));
						ResultSet r2 = pstm2.executeQuery();
						if(r2.next()) {
							new_f.setFestival_mbti(r2.getString("name"));
						}

						new_f.setFestival_image1(rs.getString("image_URL"));
						new_f.setFestival_detail(rs.getString("detail"));
						new_f.setFestival_webaddress(rs.getString("web_address"));
						new_f.setTag(rs.getString("tag"));
						new_f.setFestival_period_start(rs.getString("period_start"));
						new_f.setFestival_period_final(rs.getString("period_final"));
						new_f.setX(rs.getDouble("x"));
						new_f.setY(rs.getDouble("y"));
						list.add(new_f);
					}	
				}
			}
			return list;
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return list;
	}

	private static boolean isless(String j, String k) {
		return (j.compareTo(k) > 0);
	}

	private static void swap(String[][] e, int i, int j) {;
	String[][] tmp = new String[1][2];
	tmp[0][0] = e[i][0];
	tmp[0][1] = e[i][2];
	e[i][0] = e[j][0];
	e[i][2] = e[j][2];
	e[j][0] = tmp[0][0];
	e[j][2] = tmp[0][1];
	}

	public static ArrayList<Festival> readFestivalList_period(String [] arr) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String SQL = "SELECT * "
				+ "FROM FESTIVAL "
				+ "where PERIOD_FINAL > ? "
				+ "AND PERIOD_START < ? "
				+ "ORDER BY PERIOD_START;";
		ArrayList<Festival> list = new ArrayList<>();

		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setString(1, arr[0]);
			pstmt.setString(2, arr[1]);
			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {
				Festival new_f = new Festival();
				new_f.setI(rs.getInt("id"));
				new_f.setFestival_name(rs.getString("name"));
				new_f.setFestival_local_area(rs.getString("local_area"));
				new_f.setfestival_location(rs.getString("location"));
				new_f.setFestival_phonenumber(rs.getString("phone_number"));

				Connection con2 = null;
				PreparedStatement pstm2 = null;

				String SQL3 = "SELECT * FROM mbti where id = ?";

				con2 = DAOHandler.getConnection();
				pstm2 = con2.prepareStatement(SQL3);

				pstm2.setInt(1,rs.getInt("mbti"));
				ResultSet r2 = pstm2.executeQuery();
				if(r2.next()) {
					new_f.setFestival_mbti(r2.getString("name"));
				}

				new_f.setFestival_image1(rs.getString("image_URL"));
				new_f.setFestival_detail(rs.getString("detail"));
				new_f.setFestival_webaddress(rs.getString("web_address"));
				new_f.setTag(rs.getString("tag"));
				new_f.setFestival_period_start(rs.getString("period_start"));
				new_f.setFestival_period_final(rs.getString("period_final"));
				new_f.setX(rs.getDouble("x"));
				new_f.setY(rs.getDouble("y"));
				list.add(new_f);
			}
			return list;
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return list;
	}

	public static double readPercent(String mbti) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;

		String sql = "SELECT SUM(TEST_COUNT) FROM PERSON;";
		try {
			double sum_test_count = 0;
			double mbti_count = 0;

			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {				
				sum_test_count = rs.getDouble(1);
			}

			String sql2 = " SELECT COUNT FROM MBTI WHERE NAME = ?;";
			pstmt2 = conn.prepareStatement(sql2);
			pstmt2.setString(1, mbti);
			ResultSet rs2 = pstmt2.executeQuery();
			if(rs2.next()) {				
				mbti_count = rs2.getDouble(1);
			}

			double percent = (mbti_count / sum_test_count) * 100;
			percent = Math.floor(percent);
			if(percent != 0) {
				return percent;
			}else {
				return Protocol.READ_RES_FAIL;
			}
		}catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (pstmt2 != null) {
					pstmt2.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return Protocol.READ_RES_FAIL;
	}

	public static ArrayList<Festival> readRank() {
		Connection conn = null;
		PreparedStatement pstmt = null;

		ArrayList<Festival> list = new ArrayList<>();
		String SQL = "select distinct festival.* from festival,review where review.festival_id = festival.id order by review.star desc;";
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);
			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {
				Festival new_f = new Festival();
				new_f.setI(rs.getInt("id"));
				new_f.setFestival_name(rs.getString("name"));
				new_f.setFestival_local_area(rs.getString("local_area"));
				new_f.setfestival_location(rs.getString("location"));
				new_f.setFestival_phonenumber(rs.getString("phone_number"));

				Connection con2 = null;
				PreparedStatement pstm2 = null;

				String SQL3 = "SELECT * FROM mbti where id = ?";

				con2 = DAOHandler.getConnection();
				pstm2 = con2.prepareStatement(SQL3);

				pstm2.setInt(1,rs.getInt("mbti"));
				ResultSet r2 = pstm2.executeQuery();
				if(r2.next()) {
					new_f.setFestival_mbti(r2.getString("name"));
				}

				new_f.setFestival_image1(rs.getString("image_URL"));
				new_f.setFestival_detail(rs.getString("detail"));
				new_f.setFestival_webaddress(rs.getString("web_address"));
				new_f.setTag(rs.getString("tag"));
				new_f.setFestival_period_start(rs.getString("period_start"));
				new_f.setFestival_period_final(rs.getString("period_final"));
				new_f.setX(rs.getDouble("x"));
				new_f.setY(rs.getDouble("y"));
				list.add(new_f);
			}
			return list;
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return list;
	}

	public static ArrayList<Festival> readThumbsList(Person p)
	{
		Connection conn = null;
		PreparedStatement pstmt = null;

		String SQL = "SELECT distinct festival_id FROM Thumbs where person_id = ?";
		ArrayList<Festival> list = new ArrayList<>();
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setInt(1,p.geti());
			ResultSet rs = pstmt.executeQuery();

			Connection conn2 = null;
			PreparedStatement pstmt2 = null;

			ArrayList<Integer> f_list = new ArrayList<>();
			while (rs.next()) {
				f_list.add(rs.getInt("festival_id"));
			}
			System.out.println(f_list.size());

			StringBuilder sb = new StringBuilder();

			sb.append("SELECT distinct person_id FROM Thumbs where festival_id = ?");
			for(int i = 1; i < f_list.size(); i++) {
				sb.append(" and ?");
			}

			conn2 = DAOHandler.getConnection();
			pstmt2 = conn2.prepareStatement(sb.toString());

			for(int i = 1; i <= f_list.size(); i++) {
				pstmt2.setInt(i, f_list.get(i-1));
			}

			ResultSet rs2 = pstmt2.executeQuery();

			ArrayList<Integer> p_list = new ArrayList<>();
			while(rs2.next()) {
				p_list.add(rs2.getInt("person_id"));
			}

			System.out.println(p_list.size());
			if(p_list.size() <= 1) {
				p_list.clear();
				Connection conn3 = null;
				PreparedStatement pstmt3 = null;

				StringBuilder sb2 = new StringBuilder();

				sb2.append("SELECT distinct person_id FROM Thumbs where festival_id = ?");
				for(int i = 1; i < f_list.size(); i++) {
					sb2.append(" or festival_id = ?");
				}

				conn3 = DAOHandler.getConnection();
				pstmt3 = conn3.prepareStatement(sb2.toString());

				for(int i = 1; i <= f_list.size(); i++) {
					pstmt3.setInt(i, f_list.get(i-1));
				}

				ResultSet rs3 = pstmt3.executeQuery();
				while(rs3.next()) {
					p_list.add(rs3.getInt("person_id"));
				}

				System.out.println(p_list.size());
			}

			StringBuilder sb3 = new StringBuilder();

			sb3.append("SELECT distinct festival_id FROM Thumbs where person_id = ?");
			for(int i = 1; i < p_list.size(); i++) {
				sb3.append(" or person_id = ?");
			}

			Connection conn3 = null;
			PreparedStatement pstmt3 = null;

			conn3 = DAOHandler.getConnection();
			pstmt3 = conn3.prepareStatement(sb3.toString());

			for(int i = 1; i<=p_list.size(); i++) {
				pstmt3.setInt(i,p_list.get(i-1));
			}

			ResultSet rs3 = pstmt3.executeQuery();

			ArrayList<Integer> s_list = new ArrayList<Integer>();
			while (rs3.next()) {
				int festival = rs3.getInt("festival_id");
				if (!s_list.contains(festival)) {
					s_list.add(festival);
				}
			}
			System.out.println(s_list.size());
			Collections.sort(s_list);

			Connection conn4 = null;
			PreparedStatement pstmt4 = null;

			StringBuilder sb4 = new StringBuilder();

			sb4.append("SELECT * from festival where id = ?");
			for(int i = 1; i < s_list.size(); i++) {
				sb4.append(" or id = ?");
			}

			conn4 = DAOHandler.getConnection();
			pstmt4 = conn4.prepareStatement(sb4.toString());

			for(int i = 1; i<=s_list.size(); i++) {
				pstmt4.setInt(i,s_list.get(i-1));
			}

			ResultSet rs4 = pstmt4.executeQuery();
			while(rs4.next()) {
				Festival new_f = new Festival();
				new_f.setI(rs4.getInt("id"));
				new_f.setFestival_name(rs4.getString("name"));
				new_f.setFestival_local_area(rs4.getString("local_area"));
				new_f.setfestival_location(rs4.getString("location"));
				new_f.setFestival_phonenumber(rs4.getString("phone_number"));

				Connection con2 = null;
				PreparedStatement pstm2 = null;

				String SQL3 = "SELECT * FROM mbti where id = ?";

				con2 = DAOHandler.getConnection();
				pstm2 = con2.prepareStatement(SQL3);

				pstm2.setInt(1,rs4.getInt("mbti"));
				ResultSet r2 = pstm2.executeQuery();
				if(r2.next()) {
					new_f.setFestival_mbti(r2.getString("name"));
				}

				new_f.setFestival_image1(rs4.getString("image_URL"));
				new_f.setFestival_detail(rs4.getString("detail"));
				new_f.setFestival_webaddress(rs4.getString("web_address"));
				new_f.setTag(rs4.getString("tag"));
				new_f.setFestival_period_start(rs4.getString("period_start"));
				new_f.setFestival_period_final(rs4.getString("period_final"));
				new_f.setX(rs4.getDouble("x"));
				new_f.setY(rs4.getDouble("y"));
				list.add(new_f);
			}
			return list;
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return list;
	}
}
