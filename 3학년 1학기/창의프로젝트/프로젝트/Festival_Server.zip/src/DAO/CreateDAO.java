package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import DTO.*;
import network.Protocol;

public class CreateDAO  {
	public CreateDAO()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException cnfe) {
			System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
		}
	}

	public static int insertUser(Person p)
	{
		Connection conn = null;
		PreparedStatement pstmt = null;

		String name = p.getName();
		String id = p.getId();
		String pwd = p.getPassword();
		String phonenumber = p.getPhonenumber();
		String gender = p.getGender();
		String address = p.getAddress();
		int age = p.getAge();
		String SQL = "INSERT INTO Person(name,login_id, login_password,phonenumber, gender,address, age) VALUES(?, ?, ?, ?, ?, ?, ?)";
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setString(1, name);
			pstmt.setString(2, id);
			pstmt.setString(3, pwd);
			pstmt.setString(4, phonenumber);
			pstmt.setString(5, gender);
			pstmt.setString(6, address);
			pstmt.setInt(7, age);
			pstmt.executeUpdate();
			return Protocol.CREATE_RES_SUCCESS;

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			return Protocol.CREATE_RES_FAIL;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	}

	public static int insertReview(Review r) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String title = r.getTitle();
		String name = r.getWriter();
		int star = r.getStar();
		int festival_id = r.getFestival_id();
		String content = r.getContent();

		String SQL = "INSERT INTO Review(title,name, star,festival_id, content) VALUES(?, ?, ?, ?, ?)";
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setString(1, title);
			pstmt.setString(2, name);
			pstmt.setInt(3, star);
			pstmt.setInt(4, festival_id);
			pstmt.setString(5, content);
			pstmt.executeUpdate();
			return Protocol.CREATE_RES_SUCCESS;

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			return Protocol.CREATE_RES_FAIL;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	}

	public static int insertThumbs(Thumbs t) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		int festival_id = t.getFestival_id();
		int user_id = t.getUser_id();
		
		String SQL = "INSERT INTO Thumbs(festival_id, person_id) VALUES(?, ?)";
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setInt(1, festival_id);
			pstmt.setInt(2, user_id);
			pstmt.executeUpdate();
			return Protocol.CREATE_RES_SUCCESS;

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			return Protocol.CREATE_RES_FAIL;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	}
}
