package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import DTO.Person;
import DTO.Thumbs;
import network.Protocol;

public class DeleteDAO {
	public DeleteDAO() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException cnfe) {
			System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
		}
	}

	public static int deleteUser(Person p) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String SQL = "DELETE FROM person where id = ?";
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setInt(1,p.geti());
			pstmt.executeUpdate();

			return Protocol.DELETE_RES_SUCCESS;
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			return Protocol.DELETE_RES_FAIL;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	}

	public static int deleteReview(int id) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String SQL = "DELETE FROM review where id = ?";
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setInt(1,id);
			pstmt.executeUpdate();

			return Protocol.DELETE_RES_SUCCESS;
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			return Protocol.DELETE_RES_FAIL;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	}

	public static int deleteThumbs(Thumbs t) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String SQL = "DELETE FROM Thumbs where festival_id = ? and person_id = ?";
		try {
			conn = DAOHandler.getConnection();
			pstmt = conn.prepareStatement(SQL);

			pstmt.setInt(1,t.getFestival_id());
			pstmt.setInt(2,t.getUser_id());
			pstmt.executeUpdate();

			return Protocol.DELETE_RES_SUCCESS;
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			return Protocol.DELETE_RES_FAIL;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	}
}
