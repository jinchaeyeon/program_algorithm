package DTO;

import java.io.Serializable;

public class Tag implements Serializable{
	String name;

	public Tag(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}