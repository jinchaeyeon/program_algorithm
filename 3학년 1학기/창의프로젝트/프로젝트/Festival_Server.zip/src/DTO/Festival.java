package DTO;

import java.io.Serializable;

public class Festival implements Serializable{
	
	int i;
	String festival_name;
	String festival_local_area;
	String festival_location;
	String festival_phonenumber;
	String festival_mbti;
	String festival_image1;
	String festival_detail;
	String festival_webaddress;
	String tag;
	String festival_period_start;
	String festival_period_final;
	double x;
	double y;
	
	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}
	public String getFestival_name() {
		return festival_name;
	}
	public void setFestival_name(String festival_name) {
		this.festival_name = festival_name;
	}
	public String getFestival_local_area() {
		return festival_local_area;
	}
	public void setFestival_local_area(String festival_local_area) {
		this.festival_local_area = festival_local_area;
	}
	public String getfestival_location() {
		return festival_location;
	}
	public void setfestival_location(String festival_location) {
		this.festival_location = festival_location;
	}
	public String getFestival_phonenumber() {
		return festival_phonenumber;
	}
	public void setFestival_phonenumber(String festival_phonenumber) {
		this.festival_phonenumber = festival_phonenumber;
	}
	public String getFestival_mbti() {
		return festival_mbti;
	}
	public void setFestival_mbti(String festival_mbti) {
		this.festival_mbti = festival_mbti;
	}
	public String getFestival_image1() {
		return festival_image1;
	}
	public void setFestival_image1(String festival_image1) {
		this.festival_image1 = festival_image1;
	}
	public String getFestival_detail() {
		return festival_detail;
	}
	public void setFestival_detail(String festival_detail) {
		this.festival_detail = festival_detail;
	}
	public String getFestival_webaddress() {
		return festival_webaddress;
	}
	public void setFestival_webaddress(String festival_webaddress) {
		this.festival_webaddress = festival_webaddress;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getFestival_period_start() {
		return festival_period_start;
	}
	public void setFestival_period_start(String festival_period_start) {
		this.festival_period_start = festival_period_start;
	}
	public String getFestival_period_final() {
		return festival_period_final;
	}
	public void setFestival_period_final(String festival_period_final) {
		this.festival_period_final = festival_period_final;
	}
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	
}
