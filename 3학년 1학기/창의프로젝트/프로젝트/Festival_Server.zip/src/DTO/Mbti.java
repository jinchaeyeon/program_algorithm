package DTO;

public class Mbti{
	String mbti_name;
	int mbti_count;

	public Mbti(String mbti_name, int mbti_count) {
		this.mbti_name = mbti_name;
		this.mbti_count = mbti_count;
	}

	public String getMbti_name() {
		return mbti_name;
	}
	public void setMbti_name(String mbti_name) {
		this.mbti_name = mbti_name;
	}
	public int getMbti_count() {
		return mbti_count;
	}
	public void setMbti_count(int mbti_count) {
		this.mbti_count = mbti_count;
	}
}
