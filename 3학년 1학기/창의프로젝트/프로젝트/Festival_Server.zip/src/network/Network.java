package network;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;

import DTO.Festival;
import DTO.Mbti;
import DTO.Person;
import DTO.Review;
import DTO.Tag;
import DTO.Thumbs;

public class Network {

   private Socket socket;
   private static InputStream is;
   private static OutputStream os;

   // 네트워크 생성자
   public Network() {
      try {
         socket = new Socket("192.168.238.155", 5000);
         is = socket.getInputStream();
         os = socket.getOutputStream();
         System.out.println("서버 접속 중");
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

   // 프로토콜 송신
   private static void send(Protocol protocol) throws Exception {
      try {
         os.write(protocol.getPacket());
         System.out.println("서버에게" + " 전송");
      } catch (Exception e) {
         System.err.println(e);
      }
   }

   // 프로토콜 수신
   private static Protocol receive(int type) throws Exception {
      byte[] header = new byte[Protocol.LEN_HEADER];
      Protocol protocol = new Protocol();
      try {
         int totalReceived, readSize;
         do {
            totalReceived = 0;
            readSize = 0;
            is.read(header, 0, Protocol.LEN_HEADER);
            protocol.setPacketHeader(header);
            byte[] buf = new byte[protocol.getBodyLength()];
            while (totalReceived < protocol.getBodyLength()) {
               readSize = is.read(buf, totalReceived, protocol.getBodyLength() - totalReceived);
               totalReceived += readSize;
               if (readSize == -1) {
                  throw new Exception("통신오류: 연결 끊어짐");
               }
            }
            protocol.setPacketBody(buf);
            if (protocol.getType() == Protocol.TYPE_UNDEFINED)
               throw new Exception("통신오류: 서버에서 오류 발생함");
            else if (protocol.getType() == type)
               return protocol;
         } while (true); // 현재 필요한 응답이 아닐경우 무시하고 다음 응답을 대기
      } catch (IOException e) {
         throw new Exception("통신오류: 데이터 수신 실패함");
      }
   }

   // 로그인
   public static int login(Person person) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_LOGIN_REQ);
      protocol.setCode(Protocol.LOGIN_REQ_REQ);
      protocol.setBody(person);
      send(protocol);

      protocol = receive(Protocol.TYPE_LOGIN_RES);
      return protocol.getCode();
   }

   // 로그아웃
   public static boolean logout(Person person) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_LOGOUT_REQ);
      protocol.setCode(Protocol.LOGOUT_REQ_REQ);
      protocol.setBody(person);
      send(protocol);

      protocol = receive(Protocol.TYPE_LOGOUT_RES);
      return (protocol.getCode() == Protocol.LOGOUT_RES_SUCCESS);
   }

   // 회원가입(등록 요청)
   public static int create_Req_User(Person person) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_CREATE_REQ);
      protocol.setCode(Protocol.CREATE_REQ_USER);
      protocol.setBody(person);
      send(protocol);

      protocol = receive(Protocol.TYPE_CREATE_RES);
      return protocol.getCode();
   }

   // 리뷰 등록
   public static int create_Req_Review(Review review) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_CREATE_REQ);
      protocol.setCode(Protocol.CREATE_REQ_REVIEW);
      protocol.setBody(review);
      send(protocol);

      protocol = receive(Protocol.TYPE_CREATE_RES);
      return protocol.getCode();
   }

   // 축제 좋아요 등록
   public static int create_Req_Thumbs(Thumbs thumbs) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_CREATE_REQ);
      protocol.setCode(Protocol.CREATE_REQ_THUMBS);
      protocol.setBody(thumbs);
      send(protocol);

      protocol = receive(Protocol.TYPE_CREATE_RES);
      return protocol.getCode();
   }

   // 유저 조회
   public static Person read_Req_User(Person person) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_READ_REQ);
      protocol.setCode(Protocol.READ_REQ_USER);
      protocol.setBody(person);
      send(protocol);

      protocol = receive(Protocol.TYPE_READ_RES);
      return (Person) protocol.getBody();
   }

   // 축제 조회
   public static ArrayList<Festival> read_Req_Festival(Festival f) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_READ_REQ);
      protocol.setCode(Protocol.READ_REQ_FESTIVAL);
      protocol.setBody(f);
      send(protocol);

      protocol = receive(Protocol.TYPE_READ_RES);
      return (ArrayList<Festival>) protocol.getBody();
   }

   public static ArrayList<Festival> read_Req_Festival_period(String[] arr) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_READ_REQ);
      protocol.setCode(Protocol.READ_REQ_FESTIVAL_PERIOD);
      protocol.setBody(arr);
      send(protocol);

      protocol = receive(Protocol.TYPE_READ_RES);
      return (ArrayList<Festival>) protocol.getBody();
   }

   // 리뷰 조회
   public static ArrayList<Review> read_Req_Review(int festival_id) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_READ_REQ);
      protocol.setCode(Protocol.READ_REQ_REVIEW);
      protocol.setBody(festival_id);
      send(protocol);

      protocol = receive(Protocol.TYPE_READ_RES);
      return (ArrayList<Review>) protocol.getBody();
   }

   // mbti 조회
   public static ArrayList<Festival> read_Req_resultFestival(Tag[] t) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_READ_REQ);
      protocol.setCode(Protocol.READ_REQ_RESULTFESTIVAL);
      protocol.setBody(t);
      send(protocol);

      protocol = receive(Protocol.TYPE_READ_RES);
      return (ArrayList<Festival>) protocol.getBody();
   }

   // 태그 조회
   public static ArrayList<Tag> read_Req_Tag(String mbti) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_READ_REQ);
      protocol.setCode(Protocol.READ_REQ_TAG);
      protocol.setBody(mbti);
      send(protocol);

      protocol = receive(Protocol.TYPE_READ_RES);
      return (ArrayList<Tag>) protocol.getBody();
   }

   public static ArrayList<Festival> read_Req_Statistic_Rank_Star() throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_READ_REQ);
      protocol.setCode(Protocol.READ_REQ_STATISTIC_RANK_STAR);
      protocol.setBody(null);
      send(protocol);

      protocol = receive(Protocol.TYPE_READ_RES);
      return (ArrayList<Festival>) protocol.getBody();
   }

   public static double read_Req_Statistic_Prefer_Mbti(String mbti) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_READ_REQ);
      protocol.setCode(Protocol.READ_REQ_STATISTIC_PREFER_MBTI);
      protocol.setBody(mbti);
      send(protocol);

      protocol = receive(Protocol.TYPE_READ_RES);
      return (double) protocol.getBody();
   }

   // 좋아요 기반 축제리스트
   public static ArrayList<Festival> req_Req_Festival_By_Thumbs(Person person) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_READ_REQ);
      protocol.setCode(Protocol.READ_REQ_FESTIVAL_BY_THUMBS);
      protocol.setBody(person);
      send(protocol);

      protocol = receive(Protocol.TYPE_READ_RES);
      return (ArrayList<Festival>) protocol.getBody();
   }

   // UPDATE 요청 시작
   // 유저 업데이트
   public static int update_Req_User(Person person) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_UPDATE_REQ);
      protocol.setCode(Protocol.UPDATE_REQ_USER);
      protocol.setBody(person);
      send(protocol);

      protocol = receive(Protocol.TYPE_UPDATE_RES);
      return protocol.getCode();
   }

   // 축제 업데이트
   public static int update_Req_UserCount(Person person) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_UPDATE_REQ);
      protocol.setCode(Protocol.UPDATE_REQ_USERCOUNT);
      protocol.setBody(person);
      send(protocol);

      protocol = receive(Protocol.TYPE_UPDATE_RES);
      return protocol.getCode();
   }

   // 리뷰 업데이트
   public static int update_Req_Review(Review review) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_UPDATE_REQ);
      protocol.setCode(Protocol.UPDATE_REQ_REVIEW);
      protocol.setBody(review);
      send(protocol);

      protocol = receive(Protocol.TYPE_UPDATE_RES);
      return protocol.getCode();
   }

   // Mbti 업데이트
   public static int update_Req_Mbti(String mbti) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_UPDATE_REQ);
      protocol.setCode(Protocol.UPDATE_REQ_MBTI);
      protocol.setBody(mbti);
      send(protocol);

      protocol = receive(Protocol.TYPE_UPDATE_RES);
      return protocol.getCode();
   }

   // DELETE 시작
   // 유저 삭제
   public static int delete_Req_User(Person person) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_DELETE_REQ);
      protocol.setCode(Protocol.DELETE_REQ_USER);
      protocol.setBody(person);
      send(protocol);

      protocol = receive(Protocol.TYPE_DELETE_RES);
      return protocol.getCode();
   }

   // 리뷰 삭제
   public static int delete_Req_Review(int id) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_DELETE_REQ);
      protocol.setCode(Protocol.DELETE_REQ_REVIEW);
      protocol.setBody(id);
      send(protocol);

      protocol = receive(Protocol.TYPE_DELETE_RES);
      return protocol.getCode();
   }

   // 좋아요 삭제
   public static int delete_Req_Thumbs(Thumbs thumbs) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_DELETE_REQ);
      protocol.setCode(Protocol.DELETE_REQ_THUMBS);
      protocol.setBody(thumbs);
      send(protocol);

      protocol = receive(Protocol.TYPE_DELETE_RES);
      return protocol.getCode();
   }

   // CHECK 시작
   // ID있는지 중복검사 - 회원가입시
   public static int check_Req_Id(Person person) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_CHECK_REQ);
      protocol.setCode(Protocol.CHECK_REQ_ID);
      protocol.setBody(person);
      send(protocol);

      protocol = receive(Protocol.TYPE_CHECK_RES);
      return protocol.getCode();
   }

   // ID있는지 검사 - 로그인시
   public static int check_Req_Login_Id(Person person) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_CHECK_REQ);
      protocol.setCode(Protocol.CHECK_REQ_LOGIN_ID);
      protocol.setBody(person);
      send(protocol);

      protocol = receive(Protocol.TYPE_CHECK_RES);
      return protocol.getCode();
   }

   // PASSWD있는지 체크, 검사 - 로그인시
   public static int check_Req_Login_Passwd(Person person) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_CHECK_REQ);
      protocol.setCode(Protocol.CHECK_REQ_LOGIN_PASSWD);
      protocol.setBody(person);
      send(protocol);

      protocol = receive(Protocol.TYPE_CHECK_RES);
      return protocol.getCode();
   }

   // 좋아요 체크
   public static int check_Req_Thumbs(Thumbs thumbs) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_CHECK_REQ);
      protocol.setCode(Protocol.CHECK_REQ_THUMBS);
      protocol.setBody(thumbs);
      send(protocol);

      protocol = receive(Protocol.TYPE_CHECK_RES);
      return protocol.getCode();
   }

   // 좋아요를 눌러본 유저인가
   public static int check_Req_IsThumbs(Thumbs thumbs) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE_CHECK_REQ);
      protocol.setCode(Protocol.CHECK_REQ_ISTHUMBS);
      protocol.setBody(thumbs);
      send(protocol);

      protocol = receive(Protocol.TYPE_CHECK_RES);
      return protocol.getCode();
   }
}