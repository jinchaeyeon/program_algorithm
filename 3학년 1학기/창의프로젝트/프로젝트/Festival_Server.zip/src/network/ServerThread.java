package network;

import java.io.IOException;
import java.math.BigInteger;
import java.net.Socket;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;

import DAO.CreateDAO;
import DAO.DAOHandler;
import DAO.DeleteDAO;
import DAO.ReadDAO;
import DAO.UpdateDAO;
import DTO.Festival;
import DTO.Person;
import DTO.Review;
import DTO.Tag;
import DTO.Thumbs;

public class ServerThread extends Thread {
	private int port_ID;
	private Socket socket;
	private Connection conn;
	private Protocol p;
	private IO io;

	// 스레드 생성자
	public ServerThread(Socket socket, Connection conn) throws IOException {
		port_ID = socket.getPort();
		System.out.println("접속자 port_ID : " + port_ID);
		this.socket = socket;
		this.conn = conn;
		io = new IO(socket);
	}

	// 실행
	@Override
	public void run() {
		while (true) {
			try {
				p = io.read();
				DAOHandler.getConnection();
				handle(p);
			} catch (Exception e) {
				this.stop();
				e.printStackTrace();
			}
		}
	}

	// 기능별 서버 핸들러 -> 프로토콜 타입별
	public void handle(Protocol protocol) throws Exception {
		try {
			int packetType = protocol.getType();

			switch (packetType) {
			case Protocol.TYPE_LOGIN_REQ: { // 로그인 담당
				protocol.setType(Protocol.TYPE_CHECK_REQ);
				protocol.setCode(Protocol.CHECK_REQ_LOGIN_ID);
				Person person = (Person)protocol.getBody();
				String pw = person.getPassword();

				if(pw != null) {
					protocol.setBody(person);

					Protocol result = check_Req(protocol);
					System.out.println(result.getCode());

					result.setType(Protocol.TYPE_LOGIN_RES);
					if(result.getCode() == Protocol.LOGIN_RES_NO_ID || result.getCode() == Protocol.LOGIN_RES_NO_PASSWD) {
						io.send(result);
					}

					else if(result.getCode() == Protocol.CHECK_RES_SUCCESS) {
						result.setCode(Protocol.LOGIN_RES_SUCCESS);
						io.send(result);
					}
				}
				else {
					Protocol result = new Protocol();
					result.setType(Protocol.TYPE_LOGIN_RES);
					result.setCode(Protocol.LOGIN_RES_FAIL);
				}
			}
			break;
			case Protocol.TYPE_CREATE_REQ: { // CREATE(추가,생성) 담당
				io.send(create_Req(protocol));
				break;
			}
			case Protocol.TYPE_READ_REQ: { // READ(조회) 담당
				io.send(read_Req(protocol));
				break;
			}
			case Protocol.TYPE_UPDATE_REQ: { // UPDATE(업데이트) 담당
				io.send(update_Req(protocol));
				break;
			}
			case Protocol.TYPE_DELETE_REQ: {
				io.send(delete_Req(protocol)); // DELETE(삭제) 담당
				break;
			}
			case Protocol.TYPE_CHECK_REQ: { // CHECK(체크, 검사) 담당
				io.send(check_Req(protocol));
				break;
			}
			case Protocol.TYPE_LOGOUT_REQ: { // 로그아웃 담당
				protocol.setType(Protocol.TYPE_LOGOUT_RES);
				protocol.setCode(Protocol.LOGOUT_RES_SUCCESS);
				io.send(protocol);
				break;
			}
			default: { // 예외처리 -> UNDEFINED
				protocol.setType(Protocol.TYPE_UNDEFINED);
				io.send(protocol);
				break;
			} 
			}
		}catch (Exception e) {
			System.out.println("프로토콜 타입 구분 오류");
			e.printStackTrace();
		}
	}

	// 등록, 생성, 추가 담당 메소드 -> 코드별
	public Protocol create_Req(Protocol protocol) {
		try {
			Protocol new_protocol = new Protocol(Protocol.TYPE_CREATE_RES);

			switch (protocol.getCode()) {
			// 유저 생성
			case Protocol.CREATE_REQ_USER: {
				Protocol check = check_Req(protocol);
				if (check.getCode() == Protocol.CHECK_RES_SUCCESS) {
					Person person = (Person) protocol.getBody();
					String pw = person.getPassword();

					int signUpResult = CreateDAO.insertUser(person);
					new_protocol.setCode(signUpResult);
				} else {
					new_protocol.setCode(Protocol.CREATE_RES_FAIL);
					;
				}
				break;
			}
			// 리뷰 추가
			case Protocol.CREATE_REQ_REVIEW: {
				Review review = (Review) protocol.getBody();
				int result = CreateDAO.insertReview(review);

				if (result == protocol.CREATE_RES_SUCCESS) {
					new_protocol.setCode(Protocol.CREATE_RES_SUCCESS);
				} else {
					new_protocol.setCode(Protocol.CREATE_RES_FAIL);
				}
				break;
			}
			// 좋아요 추가
			case Protocol.CREATE_REQ_THUMBS: {
				Thumbs thumbs = (Thumbs) protocol.getBody();
				int result = CreateDAO.insertThumbs(thumbs);
				System.out.println(result);

				if (result == protocol.CREATE_RES_SUCCESS) {
					new_protocol.setCode(Protocol.CREATE_RES_SUCCESS);
				} else {
					new_protocol.setCode(Protocol.CREATE_RES_FAIL);
				}
				break;
			}
			default: {
				new_protocol.setType(Protocol.TYPE_UNDEFINED);
				break;
			}
			}
			return new_protocol;
		} catch (Exception e) {
			System.out.println("생성, 추가 오류");
			e.printStackTrace();
			return new Protocol(Protocol.TYPE_UNDEFINED);
		}
	}

	// 조회 담당 메소드 -> 코드별
	public Protocol read_Req(Protocol protocol) {
		try {
			Protocol new_protocol = new Protocol(Protocol.TYPE_READ_RES);

			switch (protocol.getCode()) {
			// 유저 조회
			case Protocol.READ_REQ_USER: {
				Person p = (Person) protocol.getBody();

				Person signUpResult = ReadDAO.readUser(p);
				new_protocol.setBody(signUpResult);
				if (new_protocol.getBody() != null) {
					new_protocol.setCode(Protocol.READ_RES_USER);
				} else {
					new_protocol.setCode(Protocol.READ_RES_FAIL);
				}
				break;
			}
			// 축제 조회
			case Protocol.READ_REQ_FESTIVAL: {
				Festival f = (Festival) protocol.getBody();

				ArrayList<Festival> list = ReadDAO.readFestivalList(f);
				new_protocol.setBody(list);
				if (protocol.getBody() != null) {
					new_protocol.setCode(Protocol.READ_RES_FESTIVAL);
				} else {
					new_protocol.setCode(Protocol.READ_RES_FAIL);
				}
				break;
			}
			case Protocol.READ_REQ_FESTIVAL_PERIOD: {
				String[] arr = (String[]) protocol.getBody();

				ArrayList<Festival> list = ReadDAO.readFestivalList_period(arr);
				new_protocol.setBody(list);
				if (protocol.getBody() != null) {
					new_protocol.setCode(Protocol.READ_RES_FESTIVAL_PERIOD);
				} else {
					new_protocol.setCode(Protocol.READ_RES_FAIL);
				}
				break;
			}
			// 리뷰 조회
			case Protocol.READ_REQ_REVIEW: {
				int id = (int) protocol.getBody();

				ArrayList<Review> list = ReadDAO.readReview(id);
				new_protocol.setBody(list);
				if (protocol.getBody() != null) {
					new_protocol.setCode(Protocol.READ_RES_REVIEW);
				} else {
					new_protocol.setCode(Protocol.READ_RES_FAIL);
				}
				break;
			}
			// MBTI 조회
			case Protocol.READ_REQ_RESULTFESTIVAL: {
				Tag[] t = (Tag[]) protocol.getBody();

				ArrayList<Festival> list = ReadDAO.result_Festival(t);
				new_protocol.setBody(list);
				if (protocol.getBody() != null) {
					new_protocol.setCode(Protocol.READ_RES_RESULTFESTIVAL);
				} else {
					new_protocol.setCode(Protocol.READ_RES_FAIL);
				}
				break;
			}
			// 태그 조회
			case Protocol.READ_REQ_TAG: {
				String mbti = (String) protocol.getBody();

				ArrayList<Tag> list = ReadDAO.readTag(mbti);
				new_protocol.setBody(list);
				if (protocol.getBody() != null) {
					new_protocol.setCode(Protocol.READ_RES_TAG);
				} else {
					new_protocol.setCode(Protocol.READ_RES_FAIL);
				}
				break;
			}
			// 별점순 축제 리스트 조회
			case Protocol.READ_REQ_STATISTIC_RANK_STAR: {
				ArrayList<Festival> list = ReadDAO.readRank();
				new_protocol.setBody(list);
				if (protocol.getBody() != null) {
					new_protocol.setCode(Protocol.READ_RES_STATISTIC_RANK_STAR);
				} else {
					new_protocol.setCode(Protocol.READ_RES_FAIL);
				}
				break;
			}
			// MBTI별 선호 축제 리스트 조회
			case Protocol.READ_REQ_STATISTIC_PREFER_MBTI: {
				String mbti = (String) protocol.getBody();

				double result = ReadDAO.readPercent(mbti);
				new_protocol.setBody(result);
				if (protocol.getBody() != null) {
					new_protocol.setCode(Protocol.READ_RES_STATISTIC_PREFER_MBTI);
				} else {
					new_protocol.setCode(Protocol.READ_RES_FAIL);
				}
				break;
			}
			case Protocol.READ_REQ_FESTIVAL_BY_THUMBS: {
				Person p = (Person) protocol.getBody();
				
				ArrayList<Festival> list= ReadDAO.readThumbsList(p);
				new_protocol.setBody(list);
				if (protocol.getBody() != null) {
					new_protocol.setCode(Protocol.READ_RES_FESTIVAL_BY_THUMBS);
				} else {
					new_protocol.setCode(Protocol.READ_RES_FAIL);
				}
				break;
			}
			default: {
				new_protocol.setType(Protocol.TYPE_UNDEFINED);
				break;
			}
			}
			return new_protocol;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("조회오류");
			return new Protocol(Protocol.TYPE_UNDEFINED);
		}
	}

	// 업데이트 담당 메소드 -> 코드별
	public Protocol update_Req(Protocol protocol) {
		try {
			Protocol new_protocol = new Protocol(Protocol.TYPE_UPDATE_RES);

			switch (protocol.getCode()) {
			// 유저 정보 업데이트
			case Protocol.UPDATE_REQ_USER: {
				Person person = (Person) protocol.getBody();
				String pw = person.getPassword();


				int result = UpdateDAO.updateUser(person);

				if (result == Protocol.UPDATE_RES_SUCCESS) {
					new_protocol.setCode(Protocol.UPDATE_RES_SUCCESS);
				} else {
					new_protocol.setCode(Protocol.UPDATE_RES_FAIL);
				}
				break;
			}
			// 축제 업데이트
			case Protocol.UPDATE_REQ_USERCOUNT: {
				int result = UpdateDAO.updateUserCount((Person) protocol.getBody());
				if (result == Protocol.UPDATE_RES_SUCCESS) {
					new_protocol.setCode(Protocol.UPDATE_RES_SUCCESS);
				} else {
					new_protocol.setCode(Protocol.UPDATE_RES_FAIL);
				}
				break;
			}
			// 리뷰 업데이트
			case Protocol.UPDATE_REQ_REVIEW: {
				int result = UpdateDAO.updateReview((Review) protocol.getBody());

				if (result == Protocol.UPDATE_RES_SUCCESS) {
					new_protocol.setCode(Protocol.UPDATE_RES_SUCCESS);
				} else {
					new_protocol.setCode(Protocol.UPDATE_RES_FAIL);
				}
				break;
			}
			// MBTI 업데이트
			case Protocol.UPDATE_REQ_MBTI: {
				int result = UpdateDAO.updateMbti((String) protocol.getBody());

				if (result == Protocol.UPDATE_RES_SUCCESS) {
					new_protocol.setCode(Protocol.UPDATE_RES_SUCCESS);
				} else {
					new_protocol.setCode(Protocol.UPDATE_RES_FAIL);
				}
				new_protocol.setCode(Protocol.UPDATE_RES_SUCCESS);
				break;
			}

			default: {
				new_protocol.setType(Protocol.TYPE_UNDEFINED);
				break;
			}
			}
			return new_protocol;
		} catch (Exception e) {
			System.out.println("업데이트 오류");
			e.printStackTrace();
			return new Protocol(Protocol.TYPE_UNDEFINED);
		}
	}

	// 삭제 담당 메소드 -> 코드별
	public Protocol delete_Req(Protocol protocol) {
		try {
			Protocol new_protocol = new Protocol(Protocol.TYPE_DELETE_RES);

			switch (protocol.getCode()) {
			// 유저 삭제
			case Protocol.DELETE_REQ_USER: {
				int result = DeleteDAO.deleteUser((Person) protocol.getBody());
				if (result == Protocol.DELETE_RES_SUCCESS) {
					new_protocol.setCode(Protocol.DELETE_RES_SUCCESS);
				} else {
					new_protocol.setCode(Protocol.DELETE_RES_FAIL);
				}
				break;
			}
			// 리뷰 삭제
			case Protocol.DELETE_REQ_REVIEW: {
				int result = DeleteDAO.deleteReview((int) protocol.getBody());
				if (result == Protocol.DELETE_RES_SUCCESS) {
					new_protocol.setCode(Protocol.DELETE_RES_SUCCESS);
				} else {
					new_protocol.setCode(Protocol.DELETE_RES_FAIL);
				}
				break;
			}
			// 좋아요 추가
			case Protocol.DELETE_REQ_THUMBS: {
				int result = DeleteDAO.deleteThumbs((Thumbs) protocol.getBody());

				if (result == protocol.DELETE_RES_SUCCESS) {
					new_protocol.setCode(Protocol.DELETE_RES_SUCCESS);
				} else {
					new_protocol.setCode(Protocol.DELETE_RES_FAIL);
				}
				break;
			}
			default: {
				new_protocol.setType(Protocol.TYPE_UNDEFINED);
			}
			}
			return new_protocol;
		} catch (Exception e) {
			System.out.println("삭제 오류");
			e.printStackTrace();
			return new Protocol(Protocol.TYPE_UNDEFINED);
		}
	}

	// 체크, 검사 담당 메소드 -> 코드별
	public Protocol check_Req(Protocol protocol) {
		try {
			Protocol new_protocol = new Protocol(Protocol.TYPE_CHECK_RES);

			switch (protocol.getCode()) {
			case Protocol.CHECK_REQ_ID: {
				Person p = (Person) protocol.getBody();

				String SQL = "SELECT count(*) FROM person where login_id = ?";
				PreparedStatement pstmt = conn.prepareStatement(SQL);
				pstmt.setString(1, p.getId());
				ResultSet rs = pstmt.executeQuery();
				int records = 0;
				while (rs.next()) {
					records = rs.getInt(1);
				}

				if (protocol.getCode() == Protocol.CHECK_REQ_ID) {
					if (records > 0) {
						new_protocol.setCode(Protocol.CHECK_RES_FAIL);
					} else {
						new_protocol.setCode(Protocol.CHECK_RES_SUCCESS);
					}
				}
				break;
			}
			// 아이디 존재 확인
			case Protocol.CHECK_REQ_LOGIN_ID:
			case Protocol.CHECK_REQ_LOGIN_PASSWD: {
				Person p = (Person) protocol.getBody();

				String SQL = "SELECT * FROM person where login_id = ?";
				PreparedStatement pstmt = conn.prepareStatement(SQL);
				pstmt.setString(1, p.getId());
				ResultSet rs = pstmt.executeQuery();
				int records = 0;
				while (rs.next()) {
					records = rs.getInt(1);
				}

				if (records == 0) {
					new_protocol.setCode(Protocol.LOGIN_RES_NO_ID);
				} else {
					String SQL2 = "SELECT * FROM person where login_password = ? and login_id = ?";
					PreparedStatement pstmt2 = conn.prepareStatement(SQL2);

					System.out.print(p.getPassword());

					pstmt2.setString(1, p.getPassword());
					pstmt2.setString(2, p.getId());
					ResultSet rs2 = pstmt2.executeQuery();
					int record = 0;
					while (rs2.next()) {
						record = rs2.getInt(1);
					}

					if (record == 0) {
						new_protocol.setCode(Protocol.LOGIN_RES_NO_PASSWD);
					} else {
						new_protocol.setCode(Protocol.CHECK_RES_SUCCESS);
					}
				}
				break;
			}
			//좋아요 눌렸는지 확인
			case Protocol.CHECK_REQ_THUMBS: {
				Thumbs t = (Thumbs) protocol.getBody();
				String SQL = "SELECT * FROM Thumbs where festival_id = ? and person_id = ?";

				PreparedStatement pstmt = conn.prepareStatement(SQL);
				pstmt.setInt(1, t.getFestival_id());
				pstmt.setInt(2, t.getUser_id());

				ResultSet rs = pstmt.executeQuery();
				int records = 0;
				while (rs.next()) {
					records = rs.getInt(1);
				}
				
				if(records == 0) {
					new_protocol.setCode(Protocol.CHECK_RES_SUCCESS);
				} else {
		
					new_protocol.setCode(Protocol.CHECK_RES_FAIL);
				}
				break;
			}
			//좋아요 눌렸는지 확인
			case Protocol.CHECK_REQ_ISTHUMBS: {
				Thumbs t = (Thumbs) protocol.getBody();
				String SQL = "SELECT * FROM Thumbs where person_id = ?";

				PreparedStatement pstmt = conn.prepareStatement(SQL);
				pstmt.setInt(1, t.getUser_id());

				ResultSet rs = pstmt.executeQuery();
				int records = 0;
				while (rs.next()) {
					records = rs.getInt(1);
				}
				
				if(records != 0) {
					new_protocol.setCode(Protocol.CHECK_RES_SUCCESS);
				} else {
					new_protocol.setCode(Protocol.CHECK_RES_FAIL);
				}
				break;
			}
			default: {
				new_protocol.setType(Protocol.TYPE_UNDEFINED);
				break;
			}
			}
			return new_protocol;
		} catch (Exception e) {
			System.out.println("체크, 검사 오류");
			e.printStackTrace();
			return new Protocol(Protocol.TYPE_UNDEFINED);
		}
	}

	public IO getIo() {
		return io;
	}

	public void setIo(IO io) {
		this.io = io;
	}

	public int getPort_ID() {
		return port_ID;
	}

	public void setPort_ID(int port_ID) {
		this.port_ID = port_ID;
	}

}