package network;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;

public class Server {
	private ServerSocket sSocket;
	private static ServerThread clients[];
	private static int client_Count;

	public static void main(String args[]) throws Exception {
		Server s = new Server();
		s.run();
	}
	
	// 서버 생성자
	public Server() throws IOException {
		sSocket = new ServerSocket(5000);
		clients = new ServerThread[50];
		client_Count = 0;
	}

	// 구동
	public void run() throws Exception {
		 while (sSocket != null) {
	            // 소켓연결
	            Socket socket = sSocket.accept();
	            
	            // DB연결
	            Connection conn = null;
	            Class.forName("com.mysql.jdbc.Driver");
	            String url = "jdbc:mysql://localhost:3306/festival_db?serverTimezone=UTC";
	            String user = "root";
	            String pw = "esj5029";
	            conn = DriverManager.getConnection(url, user, pw);
	            System.out.println("DB연결 성공");
	            // 새로운쓰레드생성
	            addThread(socket, conn);
	        }
	}

	public synchronized void addThread(Socket socket, Connection conn) throws Exception {
		if (clients.length > client_Count) {
			ServerThread st = new ServerThread(socket, conn);
			clients[client_Count] = st;
			clients[client_Count].start();
			client_Count++;
		} else {
			System.out.println("스레드풀에 할당할 수 있는 스레드가 없습니다.");
		}
	}

	public static int findClient(int port_ID) {
		for (int i = 0; i < clients.length; i++) {
			if (clients[i].getPort_ID() == port_ID) {
				return i;
			}
		}
		return -1;
	}

	public synchronized static void remove(int port_ID) throws IOException {
		try {
			int pos = findClient(port_ID);
			if (pos >= 0) {
				ServerThread toTerminate = clients[pos];
				if (pos < client_Count - 1) {
					for (int i = pos + 1; i < client_Count; i++) {
						clients[i - 1] = clients[i];
					}
				}
				client_Count--;
				System.out.println(client_Count);
				toTerminate.getIo().close();
				toTerminate.stop();
				System.out.println("[" + toTerminate.getPort_ID() + "연결 종료]");
			}
		} catch (Exception e) {
			System.out.println("스레드 종료시 문제 발생");
			e.printStackTrace();
		}
	}
}
