package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Board;
import domain.Member;
import service.BoardService;

public class BoardController implements Controller{

	private final BoardService boardService = new BoardService();
	String index = "";
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {		
		ModelAndView modelAndView = new ModelAndView();
		if(url.equals("/board/board-list")) {
			ArrayList<Board> boards = boardService.findBoards();
			modelAndView.setViewName("board/board-list");
			modelAndView.getModel().put("boards", boards);
		}	
		else if(url.equals("/board/detail")) {
			Board board = boardService.detailBoard(request.getParameter("id"));
			index = request.getParameter("id");
			modelAndView.setViewName("board/detail");
			modelAndView.getModel().put("board", board);
		}
		else if(url.equals("/board/save")) {
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("board/save");
			}
			else if(request.getMethod().equals("POST")) {
				Board board = new Board();
				board.setTitle(request.getParameter("title"));
				board.setWriter(request.getParameter("writer"));
				board.setContents(request.getParameter("contents"));
				boardService.write(board);
				modelAndView.setViewName("index");
			}
		}
		else if(url.equals("/board/delete")) {
			if(request.getMethod().equals("GET")) {
				Board board = new Board();
				board.setId(Long.valueOf(index));
				boardService.delete(board);
				ArrayList<Board> boards = boardService.findBoards();
				modelAndView.setViewName("board/board-list");
				modelAndView.setViewName("index");
			}
		}
		else if(url.equals("/board/update")) {
			if(request.getMethod().equals("GET")) {
				Board board = boardService.detailBoard(index);
				board.setId(Long.valueOf(index));
				modelAndView.setViewName("board/update");
				modelAndView.getModel().put("board", board);
			}
			else if(request.getMethod().equals("POST")) {
				Board board = new Board();
				board.setId(Long.valueOf(index));
				board.setTitle(request.getParameter("title"));
				board.setWriter(request.getParameter("writer"));
				board.setContents(request.getParameter("contents"));
				boardService.update(board);
				modelAndView.setViewName("index");
			}
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}
