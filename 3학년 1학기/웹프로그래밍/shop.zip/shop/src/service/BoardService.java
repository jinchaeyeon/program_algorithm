package service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.management.RuntimeErrorException;

import domain.Board;
import domain.Member;
import persistence.BoardRepository;

public class BoardService {
	private final BoardRepository boardRepository = BoardRepository.getInstacne();
	public BoardService() {
		
	}
	public void write(Board board) {		
		boardRepository.save(board);
	}
	public void update(Board board) {		
        boardRepository.update(board);
	}
	public void delete(Board board) {		
		boardRepository.delete(board);
	}
	public ArrayList<Board> findBoards() {
        return boardRepository.findAll();
    }
	public Board detailBoard(String s) {
        return boardRepository.findById(s);
    }
}
