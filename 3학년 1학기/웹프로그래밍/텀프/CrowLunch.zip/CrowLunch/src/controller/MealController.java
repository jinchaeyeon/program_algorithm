package controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Board;
import domain.Comment;
import domain.DailyMeal;
import domain.Meal;
import domain.Review;
import service.MealService;
import service.ReviewService;

public class MealController implements Controller{
	
	private final MealService mealService = new MealService();
	private final ReviewService reviewService=new ReviewService();
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {		
		ModelAndView modelAndView = new ModelAndView();
		if(url.equals("/meal/list")) {
			ArrayList<Meal> meals = mealService.readList(LocalDate.now());
			modelAndView.setViewName("/board/meal");
			modelAndView.getModel().put("meals", meals);
		}
		else if(url.equals("/meal/detail")) {
			int id = Integer.parseInt(request.getParameter("id"));
			LocalDate date = LocalDate.parse(request.getParameter("date"), DateTimeFormatter.ISO_DATE);
			String menu = request.getParameter("menu");
			String time = request.getParameter("time");
			Meal meal = new Meal(id, date, menu, time);
			modelAndView.setViewName("/board/meal-viewer");
			modelAndView.getModel().put("meal", meal);

			ArrayList<Review> list = reviewService.readList(id);
			modelAndView.getModel().put("reviews", list);
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}
