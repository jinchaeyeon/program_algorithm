package controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Board;
import domain.Meal;
import domain.Review;
import service.MealService;
import service.ReviewService;

public class ReviewController implements Controller{
	private final ReviewService reviewService = new ReviewService();
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {		
		ModelAndView modelAndView = new ModelAndView();
		if(url.equals("/review/list")) {
			int meal = Integer.parseInt(request.getParameter("meal"));
			ArrayList<Review> reviews = reviewService.readList(meal);
			modelAndView.setViewName("/review/list");
			modelAndView.getModel().put("reviews", reviews);
		}
		else if(url.equals("/review/post")) {
			
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("review/post");
			}
			else if(request.getMethod().equals("POST")) {
				Review review = new Review();
				review.setMeal(Integer.parseInt(request.getParameter("id")));
				review.setBody(request.getParameter("review"));
				reviewService.insert(review);
				
				int id = Integer.parseInt(request.getParameter("id"));
				LocalDate date = LocalDate.parse(request.getParameter("date"), DateTimeFormatter.ISO_DATE);
				String menu = request.getParameter("menu");
				String time = request.getParameter("time");
				Meal meal = new Meal(id, date, menu, time);
				
				modelAndView.setViewName("/board/meal-viewer");
				modelAndView.getModel().put("meal", meal);
				ArrayList<Review> list = reviewService.readList(review.getMeal());
				modelAndView.getModel().put("reviews", list);
			}
		}
		else if(url.equals("/review/delete")) 
		{
			if(request.getMethod().equals("POST")) 
			{
				reviewService.delete(Integer.parseInt(request.getParameter("review_id")));
				int id = Integer.parseInt(request.getParameter("id"));
				LocalDate date = LocalDate.parse(request.getParameter("date"), DateTimeFormatter.ISO_DATE);
				String menu = request.getParameter("menu");
				String time = request.getParameter("time");
				Meal meal = new Meal(id, date, menu, time);
				
				modelAndView.setViewName("/board/meal-viewer");
				modelAndView.getModel().put("meal", meal);
				ArrayList<Review> list = reviewService.readList(meal.getId());
				modelAndView.getModel().put("reviews", list);
			}
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}
