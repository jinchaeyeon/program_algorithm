package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import domain.Board;
import domain.DailyMeal;
import domain.User;
import service.MealService;
import service.UserService;

public class UserController implements Controller{
	private final UserService userServie = new UserService();

	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {
		ModelAndView modelAndView = new ModelAndView();

		if(url.equals("/user/sign-in")) {
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("/user/login");
			}
			else if(request.getMethod().equals("POST")) {
				String id = request.getParameter("id");
				String password = request.getParameter("password");
				User data = new User(id, "ads" , password);
				User res = userServie.logIn(data);
				if (res != null) {
					HttpSession session = request.getSession(true);
					session.setAttribute("user", res);
				}
				System.out.println(res);
				modelAndView.setViewName("/main");
				DailyMeal meal = new MealService().readDay();
				modelAndView.getModel().put("lunch", meal.getLunch());
				modelAndView.getModel().put("dinner", meal.getDinner());

			}
		}
		else if (url.equals("/user/log-out")) {
			HttpSession session = request.getSession(true);
			session.invalidate();
			modelAndView.setViewName("/main");
			DailyMeal meal = new MealService().readDay();
			modelAndView.getModel().put("lunch", meal.getLunch());
			modelAndView.getModel().put("dinner", meal.getDinner());
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}

}
