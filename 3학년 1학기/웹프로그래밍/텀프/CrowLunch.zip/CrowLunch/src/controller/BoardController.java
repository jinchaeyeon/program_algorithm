package controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import domain.Board;
import domain.Comment;
import domain.User;
import service.BoardService;
import service.CommentService;

public class BoardController implements Controller{
	private final CommentService commentService = new CommentService();
	private final BoardService boardService = new BoardService();
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {		
		ModelAndView modelAndView = new ModelAndView();
		
		if(url.equals("/board/list")) {
			
			int count = boardService.getCount();
			modelAndView.getModel().put("limit", count);
			
			int offset;
			try
			{
				offset = Integer.parseInt(request.getParameter("offset"));
				offset = (offset-1) * 10;
			}
			catch(Exception e)
			{
				offset = 0;
			}
			ArrayList<Board> boards = boardService.getList(offset, 10);
			
			HttpSession session = request.getSession(true);
			
			if (session.getAttribute("user") == null) {
				modelAndView.setViewName("board/board-list-logout");
			}else {
				modelAndView.setViewName("board/board-list");
			}
			modelAndView.getModel().put("boards", boards);
		}
		else if(url.equals("/board/detail"))
		{
			int id = Integer.parseInt(request.getParameter("id"));
			Board board = boardService.getDetail(id);
			modelAndView.setViewName("/board/board-viewer");
			modelAndView.getModel().put("board", board);
			ArrayList<Comment> list = commentService.readList(id);
			System.out.println(id);
			
			modelAndView.getModel().put("comments", list);
		}
		else if(url.equals("/board/post"))
		{
			if(request.getMethod().equals("GET")) {
					modelAndView.setViewName("board/board-make");
			}
			else if(request.getMethod().equals("POST")) {
				Board board = new Board();
				HttpSession session = request.getSession(true);
				User user = (User)session.getAttribute("user");
				board.setWriter(user.getId());
				board.setTitle(request.getParameter("title"));
				board.setBody(request.getParameter("body"));
				boardService.write(board);
			
				int count = boardService.getCount();
				modelAndView.getModel().put("limit", count);
				
				ArrayList<Board> boards = boardService.getList(0, 10);
				modelAndView.setViewName("board/board-list");
				modelAndView.getModel().put("boards", boards);
			}
		}
		else if(url.equals("/board/delete"))
		{
			int id = Integer.parseInt(request.getParameter("id"));
			boardService.delete(id);
			
			int count = boardService.getCount();
			modelAndView.getModel().put("limit", count);
			
			ArrayList<Board> boards = boardService.getList(0, 10);
			modelAndView.setViewName("board/board-list");
			modelAndView.getModel().put("boards", boards);
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}
