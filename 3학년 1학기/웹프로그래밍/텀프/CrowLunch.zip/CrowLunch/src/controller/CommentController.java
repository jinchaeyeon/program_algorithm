package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Board;
import domain.Comment;
import service.BoardService;
import service.CommentService;

public class CommentController implements Controller{
	private final CommentService commentService = new CommentService();
	private final BoardService boardService = new BoardService();
	
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {
		ModelAndView modelAndView = new ModelAndView();
		
		if(url.equals("/comment/list")) {
			int id = Integer.parseInt(request.getParameter("id"));
			ArrayList<Comment> list = commentService.readList(id);
			modelAndView.setViewName("board/board-list");
			modelAndView.getModel().put("comments", list);
			
		} else if (url.equals("/comment/post")) {
			Comment data = new Comment();
			int id = Integer.parseInt(request.getParameter("id"));
			data.setPostId(id);
			data.setBody(request.getParameter("content"));
			commentService.insert(data);
			
			Board board = boardService.getDetail(id);
			modelAndView.setViewName("/board/board-viewer");
			modelAndView.getModel().put("board", board);
			ArrayList<Comment> list = commentService.readList(id);
			modelAndView.getModel().put("comments", list);
			
		} else if (url.equals("/comment/delete")) {
			int commentId = Integer.parseInt(request.getParameter("comment_id"));
			commentService.delete(commentId);
			
			int boardId = Integer.parseInt(request.getParameter("board_id"));
			Board board = boardService.getDetail(boardId);
			modelAndView.setViewName("/board/board-viewer");
			modelAndView.getModel().put("board", board);
			ArrayList<Comment> list = commentService.readList(boardId);
			modelAndView.getModel().put("comments", list);
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}

}
