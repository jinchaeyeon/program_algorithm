package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.mysql.cj.jdbc.CallableStatement;

public abstract class DAO {// ������ ���̽� ������ ���� �߻� dao Ŭ����
	Connection con;
	PreparedStatement pstmt;
	Statement stmt;
	CallableStatement cstmt;
	ResultSet rs;

	public final void execute() {// �Ϲ� ������ ���� �޼ҵ�
		try {
			init();
			query();
			close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void transaction() { // Ʈ����� ������ ���� �޼ҵ�
		try {
			init();
			con.setAutoCommit(false);
			query();
			con.commit();
		} catch (SQLException e) {
			try {
				con.rollback();
			} catch (Exception e1) {
				System.out.println(e1.toString());
			}
			System.out.println(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void init() throws Exception { // ������ ���̽� ����
		Context context = new InitialContext();
		DataSource ds = (DataSource) context.lookup("java:comp/env/jdbc/CrowLunch");
		con = ds.getConnection();
	}

	public abstract void query() throws Exception;

	private void close() {
		if (rs != null)
			try {
				rs.close();
			} catch (Exception e) {
			}
		if (pstmt != null)
			try {
				pstmt.close();
			} catch (Exception e) {
			}
		if (con != null)
			try {
				con.close();
			} catch (Exception e) {
			}
	}

}