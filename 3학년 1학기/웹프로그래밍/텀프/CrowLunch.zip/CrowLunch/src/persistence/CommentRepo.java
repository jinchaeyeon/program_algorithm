package persistence;

import java.util.ArrayList;

import domain.Comment;

public class CommentRepo {
	ArrayList<Comment> list;

	public void insert(Comment dto) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("INSERT INTO `web`.`comments`(`writer`,`post`,`body`,`time`)\n");
				sb.append("VALUES (?, ? ,? , NOW());");

				pstmt = con.prepareStatement(sb.toString());
				pstmt.setString(1, dto.getWriter());
				pstmt.setInt(2, dto.getPostId());
				pstmt.setString(3, dto.getBody());
				pstmt.executeUpdate();
			}
		}.execute();
		
		
	}
	
	public ArrayList<Comment> readList(int postId) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("SELECT * FROM web.comments where post = ?;");

				pstmt = con.prepareStatement(sb.toString());
				pstmt.setInt(1, postId);
				rs = pstmt.executeQuery();
				list = new ArrayList<Comment>();
				while (rs.next()) {
					list.add(new Comment(rs.getInt("id"), rs.getString("writer"), rs.getInt("post"), rs.getString("body"), rs.getTimestamp("time").toLocalDateTime()));
				}
			}
		}.execute();
		
		return list;
	}
	
	public void delete(int id) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();
				
				sb.append("DELETE FROM `web`.`comments`\n");
				sb.append("WHERE id = ?;");

				pstmt = con.prepareStatement(sb.toString());
				pstmt.setInt(1, id);
				pstmt.executeUpdate();
			}
		}.execute();
	}
}
