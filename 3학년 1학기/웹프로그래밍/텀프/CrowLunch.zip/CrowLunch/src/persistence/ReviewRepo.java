package persistence;

import java.util.ArrayList;
import domain.Review;

public class ReviewRepo {
	ArrayList<Review> list;
	Review dto;
	
	public void insert(Review dto) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("INSERT INTO `web`.`reviews` (`meal`, `writer`,`body`)\n");
				sb.append("VALUES (?, ?, ?);");

				pstmt = con.prepareStatement(sb.toString());
				pstmt.setInt(1, dto.getMeal());
				pstmt.setString(2, dto.getWriter());
				pstmt.setString(3, dto.getBody());
				pstmt.executeUpdate();
			}
		}.execute();
	}
	
	public ArrayList<Review> readList(int id) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("SELECT `id`,`meal`,`body` FROM web.reviews WHERE meal = ?");

				pstmt = con.prepareStatement(sb.toString());
				pstmt.setInt(1, id);
				rs = pstmt.executeQuery();
				list = new ArrayList<Review>();
				while (rs.next()) {
					list.add(new Review(rs.getInt("id"), rs.getInt("meal"),null, rs.getString("body")));		
				}
			}
		}.execute();
		
		return list;
	}
	
	public void delete(int id) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("DELETE FROM `web`.`reviews`\n");
				sb.append("WHERE id = ?;");

				pstmt = con.prepareStatement(sb.toString());
				pstmt.setInt(1, id);
				pstmt.executeUpdate();
			}
		}.execute();
	}
}
