package persistence;

import java.util.ArrayList;

import domain.Board;

public class BoardRepo {
	ArrayList<Board> list;
	Board dto;
	int count;
	
	public void insert(Board dto) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("INSERT INTO `web`.`posts` (`writer`, `title`, `body`, `time`)\n");
				sb.append("VALUES (?, ?, ?, NOW());");
				pstmt = con.prepareStatement(sb.toString());
				pstmt.setString(1, dto.getWriter());
				pstmt.setString(2, dto.getTitle());
				pstmt.setString(3, dto.getBody());
				pstmt.executeUpdate();
			}
		}.execute();
	}
	
	public ArrayList<Board> readList(int offset, int limit) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("SELECT `id`,`writer`,`title`,`time` FROM web.posts LIMIT ? OFFSET ?;");

				pstmt = con.prepareStatement(sb.toString());
				pstmt.setInt(1, limit);
				pstmt.setInt(2, offset);
				rs = pstmt.executeQuery();
				list = new ArrayList<Board>();
				while (rs.next()) {
					list.add(new Board(rs.getInt("id"), rs.getString("writer"), rs.getString("title"), rs.getTimestamp("time").toLocalDateTime()));
				}
			}
		}.execute();
		
		return list;
	}
	
	public Board read(int id) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("SELECT * FROM web.posts where id = ?;");

				pstmt = con.prepareStatement(sb.toString());
				pstmt.setInt(1, id);
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
					dto = new Board(rs.getInt("id"), rs.getString("writer"), rs.getString("title"),rs.getString("body"), rs.getTimestamp("time").toLocalDateTime());
				}
			}
		}.execute();
		
		return dto;
	}
	
	public void delete(int id) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("DELETE FROM `web`.`posts`\n");
				sb.append("WHERE id = ?;");

				pstmt = con.prepareStatement(sb.toString());
				pstmt.setInt(1, id);
				pstmt.executeUpdate();
			}
		}.execute();
	}
	
	public int getCount(int limit) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("SELECT count(*) FROM web.posts;");

				pstmt = con.prepareStatement(sb.toString());
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
					count = rs.getInt("count(*)");
				}
			}
		}.execute();
		
		int res = (int) Math.ceil((double)count / (double)limit);
		return res;
	}
}
