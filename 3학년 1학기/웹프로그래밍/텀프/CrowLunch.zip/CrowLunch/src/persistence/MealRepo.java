package persistence;

import java.time.LocalDate;
import java.util.ArrayList;

import domain.DailyMeal;
import domain.Meal;

public class MealRepo {
	ArrayList<Meal> list;
	DailyMeal day;
	
	public ArrayList<Meal> readList(LocalDate date) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("SELECT * FROM web.meals where date >= ? limit 14;");

				pstmt = con.prepareStatement(sb.toString());
				pstmt.setString(1, date.toString());
				rs = pstmt.executeQuery();
				list = new ArrayList<Meal>();
				while (rs.next()) {
					list.add(new Meal(rs.getInt("id"), rs.getDate("date").toLocalDate(), rs.getString("menu"), rs.getString("time")));
				}
			}
		}.execute();
		
		return list;
	}
	
	public DailyMeal readDay() {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();

				sb.append("SELECT * FROM web.meals where date = curdate();");

				pstmt = con.prepareStatement(sb.toString());
				rs = pstmt.executeQuery();
				
				day = new DailyMeal(null, null);
				
				while (rs.next()) {
					Meal meal = new Meal(rs.getInt("id"), rs.getDate("date").toLocalDate(), rs.getString("menu"), rs.getString("time"));
					if (meal.getTime().equals("점심")) {
						day.setLunch(meal);
					} else if (meal.getTime().equals("저녁")) {
						day.setDinner(meal);
					} 
				}
			}
		}.execute();
		
		return day;
	}
}
