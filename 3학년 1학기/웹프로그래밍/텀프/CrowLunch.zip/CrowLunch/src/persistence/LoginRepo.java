package persistence;

import domain.User;

public class LoginRepo {
	private User res= null;
	
	public User login(String id, String password) {
		new DAO() {

			@Override
			public void query() throws Exception {
				StringBuilder sb = new StringBuilder();
				sb.append("select * from web.users\n");
				sb.append("where id = ?\n");
				sb.append("and password = ?");

				pstmt = con.prepareStatement(sb.toString());
				pstmt.setString(1, id);
				pstmt.setString(2, password);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					res = new User(rs.getString("id"), rs.getString("password"));
				}
			}
		}.execute();

		return res;
	}
}
