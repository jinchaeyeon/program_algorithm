package domain;

public class Review {
	private int id;
	private int meal;
	private String writer;
	private String body;
	
	public Review(int id, int meal, String writer,String body) {
		this.id = id;
		this.meal = meal;
		this.writer = writer;
		this.body = body;
	}
	
	public Review() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMeal() {
		return meal;
	}
	public void setMeal(int meal) {
		this.meal = meal;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
}
