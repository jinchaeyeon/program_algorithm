package domain;

import java.time.LocalDate;

public class Meal {
	private int id;
	private LocalDate date;
	private String menu;
	private String time;

	public Meal(LocalDate date, String menu, String time) {
		super();
		this.date = date;
		this.menu = menu;
		this.time = time;
	}

	public Meal(int id, LocalDate date, String menu, String time) {
		super();
		this.id = id;
		this.date = date;
		this.menu = menu;
		this.time = time;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "Meal [id=" + id + ", date=" + date + ", menu=" + menu + ", time=" + time + "]";
	}

}
