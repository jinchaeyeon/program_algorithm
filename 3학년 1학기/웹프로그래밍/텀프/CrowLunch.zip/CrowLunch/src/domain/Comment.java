package domain;

import java.time.LocalDateTime;

public class Comment {
	private int id;
	private String writer;
	private int postId;
	private String body;
	private LocalDateTime time;

	public Comment() {
		super();
	}

	public Comment(String writer, int postId, String body) {
		super();
		this.writer = writer;
		this.postId = postId;
		this.body = body;
	}

	public Comment(int id, String writer, int postId, String body, LocalDateTime time) {
		super();
		this.id = id;
		this.writer = writer;
		this.postId = postId;
		this.body = body;
		this.time = time;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public LocalDateTime getTime() {
		return time;
	}

	public void setTime(LocalDateTime time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "Comment [id=" + id + ", writer=" + writer + ", postId=" + postId + ", body=" + body + ", time=" + time
				+ "]";
	}

}
