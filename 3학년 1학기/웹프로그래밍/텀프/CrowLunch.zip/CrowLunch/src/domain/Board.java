package domain;

import java.time.LocalDateTime;

public class Board {
	private int id;
	private String writer;
	private String title;
	private String body;
	private LocalDateTime time;
	
	public Board() {}
	public Board(int id, String writer, String title, LocalDateTime time) {
		super();
		this.id = id;
		this.writer = writer;
		this.title = title;
		this.time = time;
	}

	public Board(String writer, String title, String body) {
		super();
		this.writer = writer;
		this.title = title;
		this.body = body;
	}

	public Board(int id, String writer, String title, String body, LocalDateTime time) {
		super();
		this.id = id;
		this.writer = writer;
		this.title = title;
		this.body = body;
		this.time = time;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public LocalDateTime getTime() {
		return time;
	}

	public void setTime(LocalDateTime time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "BoardDTO [id=" + id + ", writer=" + writer + ", title=" + title + ", body=" + body + ", time=" + time
				+ "]";
	}
}
