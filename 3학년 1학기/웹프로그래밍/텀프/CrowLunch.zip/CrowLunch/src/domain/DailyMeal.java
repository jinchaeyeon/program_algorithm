package domain;

public class DailyMeal {
	private Meal lunch;
	private Meal dinner;

	public DailyMeal(Meal lunch, Meal dinner) {
		super();
		this.lunch = lunch;
		this.dinner = dinner;
	}

	public Meal getLunch() {
		return lunch;
	}

	public void setLunch(Meal lunch) {
		this.lunch = lunch;
	}

	public Meal getDinner() {
		return dinner;
	}

	public void setDinner(Meal dinner) {
		this.dinner = dinner;
	}

	@Override
	public String toString() {
		return "DailyMeal [lunch=" + lunch + ", dinner=" + dinner + "]";
	}

}
