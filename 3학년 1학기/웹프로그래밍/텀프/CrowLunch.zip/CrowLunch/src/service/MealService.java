package service;

import java.time.LocalDate;
import java.util.ArrayList;

import domain.DailyMeal;
import domain.Meal;
import persistence.MealRepo;

public class MealService 
{
	MealRepo mealRepo = new MealRepo();
	
	public MealService() {}
	
	public ArrayList<Meal> readList(LocalDate date)
	{
		return mealRepo.readList(date);
	}
	
	public DailyMeal readDay() {
		return mealRepo.readDay();
	}
}
