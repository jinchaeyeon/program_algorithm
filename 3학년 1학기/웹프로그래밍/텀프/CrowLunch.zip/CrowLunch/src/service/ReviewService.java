package service;

import java.util.ArrayList;

import domain.Review;
import persistence.ReviewRepo;

public class ReviewService {
	ReviewRepo reviewRepo =  new ReviewRepo();
	
	public ReviewService() { }

	public void insert(Review review) {
		review.setWriter("null");
		reviewRepo.insert(review);
	}
	public ArrayList<Review> readList(int id) {
		return reviewRepo.readList(id);
	}
	public void delete(int id) { 
		reviewRepo.delete(id);
	}
}
