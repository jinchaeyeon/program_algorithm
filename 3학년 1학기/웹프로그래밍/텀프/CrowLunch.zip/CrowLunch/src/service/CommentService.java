package service;

import java.util.ArrayList;

import domain.Comment;
import persistence.CommentRepo;

public class CommentService {
	CommentRepo commentRepo = new CommentRepo();
	
	public CommentService() {}
	public void insert(Comment dto)
	{
		dto.setWriter("null");
		commentRepo.insert(dto);
	}
	public ArrayList<Comment> readList(int postId)
	{ 
		return commentRepo.readList(postId);
	}
	public void delete(int id)
	{ 
		commentRepo.delete(id);
	}
	
}
