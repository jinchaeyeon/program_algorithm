package service;

import domain.User;
import persistence.LoginRepo;

public class UserService {
	public User logIn(User data) {
		System.out.println(data);
		return new LoginRepo().login(data.getId(), data.getPassword());
	}
}
