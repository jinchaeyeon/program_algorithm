package service;

import java.util.ArrayList;

import domain.Board;
import persistence.BoardRepo;

public class BoardService {
	public BoardService() {
		
	}
	
	public void write(Board data) {
		new BoardRepo().insert(data);
	}
	
	public ArrayList<Board> getList(int offset, int limit) {
		return new BoardRepo().readList(offset, limit);
	}
	
	public Board getDetail(int id) {
		return new BoardRepo().read(id);
	}
	
	public void delete(int id) {
		new BoardRepo().delete(id);
	}
	
	public int getCount() {
		return new BoardRepo().getCount(10);
	}
}
